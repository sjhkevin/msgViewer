using FluentFTP;
using SamBQ.Models;
using System.Text;

namespace SamBQ.Forms
{
    public partial class FtpDownloadPage : UserControl
    {
        // ── State ──
        private AsyncFtpClient? _ftp;
        private ConnectionProfile? _profile;
        private List<CsvDownloadItem> _csvItems = new();
        private CancellationTokenSource? _cts;
        private const long MaxTotalBytes = 30L * 1024 * 1024 * 1024; // 30 GB

        public FtpDownloadPage()
        {
            InitializeComponent();
        }

        // ── 이벤트 핸들러 (Stop / Browse) ─────────────────────────
        private void BtnStop_Click(object? sender, EventArgs e) => _cts?.Cancel();

        private void BtnBrowse_Click(object? sender, EventArgs e)
        {
            using var dlg = new FolderBrowserDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
                txtLocalPath.Text = dlg.SelectedPath;
        }

        private void BtnOpenFolder_Click(object? sender, EventArgs e)
        {
            var path = txtLocalPath.Text.Trim();
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path))
            {
                MessageBox.Show("유효한 저장 경로를 먼저 선택하세요.", "알림");
                return;
            }
            System.Diagnostics.Process.Start("explorer.exe", path);
        }

        // ── 공개 접속 메서드 ─────────────────────────────────────
        public async Task ConnectAsync(ConnectionProfile profile)
        {
            _profile = profile;
            _ftp = new AsyncFtpClient(profile.Host, profile.UserId, profile.Password, profile.Port);
            await _ftp.Connect();
            await LoadRootAsync();
        }

        private async Task LoadRootAsync()
        {
            treeServer.Nodes.Clear();
            var root = new TreeNode("/") { Tag = "/" };
            root.Nodes.Add(new TreeNode("...")); // 지연 로딩용 더미
            treeServer.Nodes.Add(root);
            await Task.CompletedTask;
        }

        // ── 트리 지연 로딩 ───────────────────────────────────────
        private async void TreeServer_BeforeExpand(object? sender, TreeViewCancelEventArgs e)
        {
            var node = e.Node;
            if (node == null || _ftp == null) return;
            if (node.Nodes.Count == 1 && node.Nodes[0].Text == "...")
            {
                node.Nodes.Clear();
                string path = node.Tag?.ToString() ?? "/";
                try
                {
                    var items = await _ftp.GetListing(path);
                    foreach (var item in items
                        .Where(i => i.Type == FtpObjectType.Directory)
                        .OrderBy(i => i.Name))
                    {
                        var child = new TreeNode(item.Name) { Tag = item.FullName };
                        child.Nodes.Add(new TreeNode("..."));
                        node.Nodes.Add(child);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"디렉토리 로드 오류:\n{ex.Message}", "오류");
                }
            }
        }

        // ── 트리 선택 → 파일 목록 갱신 ─────────────────────────
        private async void TreeServer_AfterSelect(object? sender, TreeViewEventArgs e)
        {
            if (_ftp == null || e.Node == null) return;
            string path = e.Node.Tag?.ToString() ?? "/";
            lblCurrentPath.Text = $"현재 경로: {path}";
            listFiles.Items.Clear();
            try
            {
                var items = await _ftp.GetListing(path);
                foreach (var item in items
                    .Where(i => i.Type == FtpObjectType.File)
                    .OrderBy(i => i.Name))
                {
                    var lvi = new ListViewItem(item.Name);
                    lvi.SubItems.Add(FormatSize(item.Size));
                    lvi.SubItems.Add(item.Modified.ToString("yyyy-MM-dd HH:mm:ss"));
                    lvi.Tag = item;
                    listFiles.Items.Add(lvi);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"파일 목록 오류:\n{ex.Message}", "오류");
            }
        }

        // ── 단일 검색 ────────────────────────────────────────────
        private async void BtnSearch_Click(object? sender, EventArgs e)
        {
            if (_ftp == null) { MessageBox.Show("서버에 접속되어 있지 않습니다."); return; }
            string currentPath = treeServer.SelectedNode?.Tag?.ToString() ?? "/";
            string keyword = txtSearchFile.Text.Trim();
            if (string.IsNullOrEmpty(keyword)) { MessageBox.Show("검색할 파일명을 입력하세요."); return; }

            listFiles.Items.Clear();
            btnSearch.Enabled = false;
            try
            {
                var results = await SearchFilesAsync(currentPath, keyword, chkLike.Checked);
                foreach (var item in results)
                {
                    var lvi = new ListViewItem(item.Name);
                    lvi.SubItems.Add(FormatSize(item.Size));
                    lvi.SubItems.Add(item.Modified.ToString("yyyy-MM-dd HH:mm:ss"));
                    lvi.Tag = item;
                    listFiles.Items.Add(lvi);
                }
                MessageBox.Show($"검색 완료: {results.Count}개 파일 발견", "검색 결과");
            }
            catch (Exception ex) { MessageBox.Show($"검색 오류:\n{ex.Message}", "오류"); }
            finally { btnSearch.Enabled = true; }
        }

        private async Task<List<FtpListItem>> SearchFilesAsync(string path, string keyword, bool like)
        {
            var result = new List<FtpListItem>();
            if (_ftp == null) return result;
            var items = await _ftp.GetListing(path);
            foreach (var item in items)
            {
                if (item.Type == FtpObjectType.File)
                {
                    bool match = like
                        ? item.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                        : item.Name.Equals(keyword, StringComparison.OrdinalIgnoreCase);
                    if (match) result.Add(item);
                }
                else if (item.Type == FtpObjectType.Directory)
                {
                    result.AddRange(await SearchFilesAsync(item.FullName, keyword, like));
                }
            }
            return result;
        }

        // ── CSV 업로드 ───────────────────────────────────────────
        private void BtnCsvUpload_Click(object? sender, EventArgs e)
        {
            using var dlg = new OpenFileDialog { Filter = "CSV 파일|*.csv" };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            _csvItems = ParseCsv(dlg.FileName);
            lblCsvCount.Text = $"총 {_csvItems.Count}개";
            MessageBox.Show($"CSV 로드 완료: {_csvItems.Count}개 항목", "알림");
        }

        private static List<CsvDownloadItem> ParseCsv(string path)
        {
            var list = new List<CsvDownloadItem>();
            // FileShare.ReadWrite → Excel 등에서 파일을 열고 있어도 읽기 가능
            string[] lines;
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var sr = new StreamReader(fs, Encoding.UTF8))
            {
                lines = sr.ReadToEnd().Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            }
            foreach (var line in lines.Skip(1))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                var parts = line.Split(',');
                list.Add(new CsvDownloadItem
                {
                    RemotePath  = parts.Length > 0 ? parts[0].Trim() : "",
                    FileName    = parts.Length > 1 ? parts[1].Trim() : "",
                    LikeSearch  = parts.Length > 2 && parts[2].Trim().Equals("yes", StringComparison.OrdinalIgnoreCase),
                    RenameFile  = parts.Length > 3 && parts[3].Trim().Equals("yes", StringComparison.OrdinalIgnoreCase),
                    NewFileName = parts.Length > 4 ? parts[4].Trim() : ""
                });
            }
            return list;
        }

        // ── 다중 처리 시작 ───────────────────────────────────────
        private async void BtnMultiStart_Click(object? sender, EventArgs e)
        {
            if (_ftp == null)  { MessageBox.Show("서버에 접속되어 있지 않습니다."); return; }
            if (_csvItems.Count == 0) { MessageBox.Show("CSV 파일을 먼저 업로드하세요."); return; }
            if (string.IsNullOrEmpty(txtLocalPath.Text)) { MessageBox.Show("저장 경로를 선택하세요."); return; }

            _cts = new CancellationTokenSource();
            progressBar.Maximum = _csvItems.Count;
            progressBar.Value = 0;
            btnMultiStart.Enabled = false;

            double intervalMs = (double)numInterval.Value * 1000;
            long totalBytes = 0;
            int done = 0;

            foreach (var item in _csvItems)
            {
                if (_cts.Token.IsCancellationRequested) break;
                try
                {
                    var files = await SearchFilesAsync(item.RemotePath, item.FileName, item.LikeSearch);
                    foreach (var f in files)
                    {
                        if (_cts.Token.IsCancellationRequested) goto Finish;

                        bool willExceed = totalBytes + f.Size > MaxTotalBytes;
                        await DownloadFileAsync(f, item, txtLocalPath.Text);
                        totalBytes += f.Size;

                        if (willExceed)
                        {
                            MessageBox.Show(
                                "다운로드 총 파일 사이즈 30GB를 초과하였습니다.\n다운로드를 중단합니다.",
                                "용량 초과", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            goto Finish;
                        }
                        await Task.Delay((int)intervalMs);
                    }
                }
                catch (Exception ex) { item.Status = $"오류: {ex.Message}"; }

                done++;
                progressBar.Value = done;
                lblProgress.Text = $"{done} / {_csvItems.Count}";
                Application.DoEvents();
                await Task.Delay((int)intervalMs);
            }

        Finish:
            btnMultiStart.Enabled = true;
            if (!_cts.Token.IsCancellationRequested)
                MessageBox.Show("다중 처리가 완료되었습니다.", "완료");
        }

        private async Task DownloadFileAsync(FtpListItem remoteFile, CsvDownloadItem item, string localDir)
        {
            string localFile = Path.Combine(localDir, remoteFile.Name);
            await _ftp!.DownloadFile(localFile, remoteFile.FullName, FtpLocalExists.Overwrite);

            if (item.RenameFile && !string.IsNullOrEmpty(item.NewFileName))
            {
                string dest = Path.Combine(localDir, item.NewFileName);
                if (File.Exists(dest)) File.Delete(dest);
                File.Move(localFile, dest);
            }
        }

        // ── 선택 파일 다운로드 ───────────────────────────────────
        private async void BtnDownloadSelected_Click(object? sender, EventArgs e)
        {
            if (_ftp == null) { MessageBox.Show("서버에 접속되어 있지 않습니다."); return; }
            if (string.IsNullOrEmpty(txtLocalPath.Text)) { MessageBox.Show("저장 경로를 선택하세요."); return; }

            var selected = listFiles.CheckedItems
                .Cast<ListViewItem>()
                .Where(i => i.Tag is FtpListItem)
                .ToList();
            if (selected.Count == 0) { MessageBox.Show("다운로드할 파일을 체크하세요."); return; }

            progressBar.Maximum = selected.Count;
            progressBar.Value = 0;
            double intervalMs = (double)numInterval.Value * 1000;
            long totalBytes = 0;
            int done = 0;

            foreach (var lvi in selected)
            {
                var ftpItem = (FtpListItem)lvi.Tag!;
                bool willExceed = totalBytes + ftpItem.Size > MaxTotalBytes;

                string localFile = Path.Combine(txtLocalPath.Text, ftpItem.Name);
                await _ftp.DownloadFile(localFile, ftpItem.FullName, FtpLocalExists.Overwrite);
                totalBytes += ftpItem.Size;
                done++;
                progressBar.Value = done;
                lblProgress.Text = $"{done} / {selected.Count}";
                Application.DoEvents();

                if (willExceed)
                {
                    MessageBox.Show("다운로드 총 파일 사이즈 30GB를 초과하였습니다.", "용량 초과",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
                }
                await Task.Delay((int)intervalMs);
            }
            MessageBox.Show("선택 파일 다운로드가 완료되었습니다.", "완료");
        }

        // ── 유틸 ─────────────────────────────────────────────────
        private static string FormatSize(long bytes)
        {
            if (bytes >= 1024L * 1024 * 1024) return $"{bytes / (1024.0 * 1024 * 1024):F2} GB";
            if (bytes >= 1024 * 1024)         return $"{bytes / (1024.0 * 1024):F2} MB";
            if (bytes >= 1024)                return $"{bytes / 1024.0:F1} KB";
            return $"{bytes} B";
        }
    }
}
