using FluentFTP;
using SamBQ.Models;
using System.Text;
using System.Text.Json;

namespace SamBQ.Forms
{
    public partial class FtpDownloadPage : UserControl
    {
        // ── State ──
        private AsyncFtpClient? _ftp;
        private ConnectionProfile? _profile;
        private List<CsvDownloadItem> _csvItems = new();
        private CancellationTokenSource? _cts;
        private const long MaxTotalBytes = 30L * 1024 * 1024 * 1024; // 30 GB

        // ── 리스팅 캐시 (중복 FTP 호출 방지) ──
        private string? _cachedListingPath;
        private FtpListItem[]? _cachedListingItems;

        // ── 즐겨찾기 ──
        private List<string> _favorites = new();
        private static readonly string FavoritesFilePath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ftp_favorites.json");

        // ── 설정 (저장경로 유지) ──
        private static readonly string SettingsFilePath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ftp_settings.json");

        public FtpDownloadPage()
        {
            InitializeComponent();
            LoadFavorites();
            LoadSavePath();
        }

        // ── 이벤트 핸들러 (Stop / Browse) ─────────────────────────
        private void BtnStop_Click(object? sender, EventArgs e) => _cts?.Cancel();

        private void BtnBrowse_Click(object? sender, EventArgs e)
        {
            using var dlg = new FolderBrowserDialog();
            if (!string.IsNullOrEmpty(txtLocalPath.Text) && Directory.Exists(txtLocalPath.Text))
                dlg.SelectedPath = txtLocalPath.Text;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                txtLocalPath.Text = dlg.SelectedPath;
                SaveSavePath();
            }
        }

        private void BtnReadMe_Click(object? sender, EventArgs e)
        {
            string readmePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ReadMe.txt");
            if (!File.Exists(readmePath))
            {
                MessageBox.Show("ReadMe.txt 파일이 존재하지 않습니다.\n경로: " + readmePath, "알림");
                return;
            }
            System.Diagnostics.Process.Start("notepad.exe", readmePath);
        }

        private void BtnOpenFolder_Click(object? sender, EventArgs e)
        {
            var path = txtLocalPath.Text.Trim();
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path))
            {
                MessageBox.Show("유효한 저장 경로를 먼저 선택하세요.", "알림");
                return;
            }
            System.Diagnostics.Process.Start("explorer.exe", path);
        }

        // ── 공개 접속 메서드 ─────────────────────────────────────
        public async Task ConnectAsync(ConnectionProfile profile)
        {
            _profile = profile;
            _ftp = new AsyncFtpClient(profile.Host, profile.UserId, profile.Password, profile.Port);
            await _ftp.Connect();
            await LoadRootAsync();
        }

        private async Task LoadRootAsync()
        {
            treeServer.Nodes.Clear();
            var root = new TreeNode("/") { Tag = "/" };
            root.Nodes.Add(new TreeNode("...")); // 지연 로딩용 더미
            treeServer.Nodes.Add(root);
            await Task.CompletedTask;
        }

        // ── 리스팅 캐시 헬퍼 (같은 경로 중복 FTP 호출 방지) ────
        private async Task<FtpListItem[]> GetListingCachedAsync(string path)
        {
            if (_cachedListingPath == path && _cachedListingItems != null)
                return _cachedListingItems;

            var items = await _ftp!.GetListing(path);
            _cachedListingPath = path;
            _cachedListingItems = items;
            return items;
        }

        // ── 트리 지연 로딩 ───────────────────────────────────────
        private async void TreeServer_BeforeExpand(object? sender, TreeViewCancelEventArgs e)
        {
            var node = e.Node;
            if (node == null || _ftp == null) return;
            if (node.Nodes.Count == 1 && node.Nodes[0].Text == "...")
            {
                node.Nodes.Clear();
                string path = node.Tag?.ToString() ?? "/";
                try
                {
                    var items = await GetListingCachedAsync(path);
                    foreach (var item in items
                        .Where(i => i.Type == FtpObjectType.Directory)
                        .OrderBy(i => i.Name))
                    {
                        var child = new TreeNode(item.Name) { Tag = item.FullName };
                        child.Nodes.Add(new TreeNode("..."));
                        node.Nodes.Add(child);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"디렉토리 로드 오류:\n{ex.Message}", "오류");
                }
            }
        }

        // ── 트리 선택 → 파일 목록 갱신 ─────────────────────────
        private async void TreeServer_AfterSelect(object? sender, TreeViewEventArgs e)
        {
            if (_ftp == null || e.Node == null) return;
            string path = e.Node.Tag?.ToString() ?? "/";
            lblCurrentPath.Text = $"현재 경로: {path}";
            listFiles.Items.Clear();
            try
            {
                var items = await GetListingCachedAsync(path);
                foreach (var item in items
                    .Where(i => i.Type == FtpObjectType.File)
                    .OrderBy(i => i.Name))
                {
                    var lvi = new ListViewItem(item.Name);
                    lvi.SubItems.Add(FormatSize(item.Size));
                    lvi.SubItems.Add(item.Modified.ToString("yyyy-MM-dd HH:mm:ss"));
                    lvi.Tag = item;
                    listFiles.Items.Add(lvi);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"파일 목록 오류:\n{ex.Message}", "오류");
            }
        }

        // ── 단일 검색 ────────────────────────────────────────────
        private async void BtnSearch_Click(object? sender, EventArgs e)
        {
            if (_ftp == null) { MessageBox.Show("서버에 접속되어 있지 않습니다."); return; }
            string currentPath = treeServer.SelectedNode?.Tag?.ToString() ?? "/";
            string keyword = txtSearchFile.Text.Trim();
            if (string.IsNullOrEmpty(keyword)) { MessageBox.Show("검색할 파일명을 입력하세요."); return; }

            listFiles.Items.Clear();
            lblSelectedPath.Text = "";
            btnSearch.Enabled = false;
            try
            {
                var results = await SearchFilesAsync(currentPath, keyword, chkLike.Checked);
                foreach (var item in results)
                {
                    var lvi = new ListViewItem(item.Name);
                    if (item.Type == FtpObjectType.Directory)
                    {
                        lvi.SubItems.Add("[폴더]");
                        lvi.ForeColor = Color.FromArgb(0, 100, 180);
                    }
                    else
                    {
                        lvi.SubItems.Add(FormatSize(item.Size));
                    }
                    lvi.SubItems.Add(item.Modified.ToString("yyyy-MM-dd HH:mm:ss"));
                    lvi.Tag = item;
                    listFiles.Items.Add(lvi);
                }
                int folderCnt = results.Count(r => r.Type == FtpObjectType.Directory);
                int fileCnt = results.Count - folderCnt;
                MessageBox.Show($"검색 완료: 폴더 {folderCnt}개, 파일 {fileCnt}개 발견", "검색 결과");
            }
            catch (Exception ex) { MessageBox.Show($"검색 오류:\n{ex.Message}", "오류"); }
            finally { btnSearch.Enabled = true; }
        }

        private async Task<List<FtpListItem>> SearchFilesAsync(string path, string keyword, bool like)
        {
            var result = new List<FtpListItem>();
            if (_ftp == null) return result;
            var items = await _ftp.GetListing(path);
            foreach (var item in items)
            {
                bool match = like
                    ? item.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                    : item.Name.Equals(keyword, StringComparison.OrdinalIgnoreCase);

                if (item.Type == FtpObjectType.File)
                {
                    if (match) result.Add(item);
                }
                else if (item.Type == FtpObjectType.Directory)
                {
                    if (match) result.Add(item); // 폴더명도 검색 대상
                    result.AddRange(await SearchFilesAsync(item.FullName, keyword, like));
                }
            }
            return result;
        }

        // ── CSV 업로드 ───────────────────────────────────────────
        private void BtnCsvUpload_Click(object? sender, EventArgs e)
        {
            using var dlg = new OpenFileDialog { Filter = "텍스트 파일|*.txt" };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            _csvItems = ParseCsv(dlg.FileName);
            lblCsvCount.Text = $"총 {_csvItems.Count}개";
            MessageBox.Show($"CSV 로드 완료: {_csvItems.Count}개 항목", "알림");
        }

        private static List<CsvDownloadItem> ParseCsv(string path)
        {
            var list = new List<CsvDownloadItem>();
            // FileShare.ReadWrite → Excel 등에서 파일을 열고 있어도 읽기 가능
            string[] lines;
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var sr = new StreamReader(fs, Encoding.UTF8))
            {
                lines = sr.ReadToEnd().Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            }
            foreach (var line in lines.Skip(1))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                var parts = line.Split("^^");
                list.Add(new CsvDownloadItem
                {
                    RemotePath  = parts.Length > 0 ? parts[0].Trim() : "",
                    FileName    = parts.Length > 1 ? parts[1].Trim() : "",
                    LikeSearch  = parts.Length > 2 && parts[2].Trim().Equals("yes", StringComparison.OrdinalIgnoreCase),
                    RenameFile  = parts.Length > 3 && parts[3].Trim().Equals("yes", StringComparison.OrdinalIgnoreCase),
                    NewFileName = parts.Length > 4 ? parts[4].Trim() : ""
                });
            }
            return list;
        }

        // ── 다중 처리 시작 ───────────────────────────────────────
        private async void BtnMultiStart_Click(object? sender, EventArgs e)
        {
            if (_ftp == null)  { MessageBox.Show("서버에 접속되어 있지 않습니다."); return; }
            if (_csvItems.Count == 0) { MessageBox.Show("CSV 파일을 먼저 업로드하세요."); return; }
            if (string.IsNullOrEmpty(txtLocalPath.Text)) { MessageBox.Show("저장 경로를 선택하세요."); return; }

            _cts = new CancellationTokenSource();
            progressBar.Maximum = _csvItems.Count;
            progressBar.Value = 0;
            btnMultiStart.Enabled = false;

            // 가이드 라벨을 진행 상태 표시용으로 전환
            string origGuideText = lblGuide.Text;
            var origGuideColor = lblGuide.ForeColor;
            var origGuideFont = lblGuide.Font;
            lblGuide.Font = new Font(lblGuide.Font.FontFamily, 9F, FontStyle.Bold);
            lblGuide.ForeColor = Color.FromArgb(0, 122, 204);

            double intervalMs = (double)numInterval.Value * 1000;
            long totalBytes = 0;
            int done = 0;

            foreach (var item in _csvItems)
            {
                if (_cts.Token.IsCancellationRequested) break;
                try
                {
                    lblGuide.Text = $"▶ [{done + 1}/{_csvItems.Count}] 검색 중: {item.RemotePath}/{item.FileName}";
                    lblGuide.Refresh();

                    var files = await SearchFilesAsync(item.RemotePath, item.FileName, item.LikeSearch);
                    foreach (var f in files)
                    {
                        if (_cts.Token.IsCancellationRequested) goto Finish;

                        lblGuide.Text = $"▶ [{done + 1}/{_csvItems.Count}] 다운로드 중: {f.Name} ({FormatSize(f.Size)})";
                        lblGuide.Refresh();

                        bool willExceed = totalBytes + f.Size > MaxTotalBytes;
                        await DownloadFileAsync(f, item, txtLocalPath.Text);
                        totalBytes += f.Size;

                        if (willExceed)
                        {
                            MessageBox.Show(
                                "다운로드 총 파일 사이즈 30GB를 초과하였습니다.\n다운로드를 중단합니다.",
                                "용량 초과", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            goto Finish;
                        }
                        await Task.Delay((int)intervalMs);
                    }
                }
                catch (Exception ex) { item.Status = $"오류: {ex.Message}"; }

                done++;
                progressBar.Value = done;
                lblProgress.Text = $"{done} / {_csvItems.Count}";
                await Task.Delay((int)intervalMs);
            }

        Finish:
            // 가이드 라벨 원래 상태로 복원
            lblGuide.Text = origGuideText;
            lblGuide.ForeColor = origGuideColor;
            lblGuide.Font = origGuideFont;
            btnMultiStart.Enabled = true;
            if (!_cts.Token.IsCancellationRequested)
                MessageBox.Show("다중 처리가 완료되었습니다.", "완료");
        }

        private async Task DownloadFileAsync(FtpListItem remoteFile, CsvDownloadItem item, string localDir)
        {
            string localFile = Path.Combine(localDir, remoteFile.Name);
            await _ftp!.DownloadFile(localFile, remoteFile.FullName, FtpLocalExists.Overwrite);

            if (item.RenameFile && !string.IsNullOrEmpty(item.NewFileName))
            {
                string dest = Path.Combine(localDir, item.NewFileName);
                if (File.Exists(dest)) File.Delete(dest);
                File.Move(localFile, dest);
            }
        }

        // ── 선택 파일 다운로드 ───────────────────────────────────
        private async void BtnDownloadSelected_Click(object? sender, EventArgs e)
        {
            if (_ftp == null) { MessageBox.Show("서버에 접속되어 있지 않습니다."); return; }
            if (string.IsNullOrEmpty(txtLocalPath.Text)) { MessageBox.Show("저장 경로를 선택하세요."); return; }

            var selected = listFiles.CheckedItems
                .Cast<ListViewItem>()
                .Where(i => i.Tag is FtpListItem)
                .ToList();
            if (selected.Count == 0) { MessageBox.Show("다운로드할 파일을 체크하세요."); return; }

            progressBar.Maximum = selected.Count;
            progressBar.Value = 0;
            btnDownloadSel.Enabled = false;

            // 가이드 라벨을 진행 상태 표시용으로 전환
            string origGuideText = lblGuide.Text;
            var origGuideColor = lblGuide.ForeColor;
            var origGuideFont = lblGuide.Font;
            lblGuide.Font = new Font(lblGuide.Font.FontFamily, 9F, FontStyle.Bold);
            lblGuide.ForeColor = Color.FromArgb(0, 122, 204);

            double intervalMs = (double)numInterval.Value * 1000;
            long totalBytes = 0;
            int done = 0;

            foreach (var lvi in selected)
            {
                var ftpItem = (FtpListItem)lvi.Tag!;
                bool willExceed = totalBytes + ftpItem.Size > MaxTotalBytes;

                lblGuide.Text = $"▶ [{done + 1}/{selected.Count}] 다운로드 중: {ftpItem.Name} ({FormatSize(ftpItem.Size)})";
                lblGuide.Refresh();

                string localFile = Path.Combine(txtLocalPath.Text, ftpItem.Name);
                await _ftp.DownloadFile(localFile, ftpItem.FullName, FtpLocalExists.Overwrite);
                totalBytes += ftpItem.Size;
                done++;
                progressBar.Value = done;
                lblProgress.Text = $"{done} / {selected.Count}";

                if (willExceed)
                {
                    MessageBox.Show("다운로드 총 파일 사이즈 30GB를 초과하였습니다.", "용량 초과",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
                }
                await Task.Delay((int)intervalMs);
            }

            // 가이드 라벨 원래 상태로 복원
            lblGuide.Text = origGuideText;
            lblGuide.ForeColor = origGuideColor;
            lblGuide.Font = origGuideFont;
            btnDownloadSel.Enabled = true;
            MessageBox.Show("선택 파일 다운로드가 완료되었습니다.", "완료");
        }

        // ── 저장경로 유지 ─────────────────────────────────────────
        private void LoadSavePath()
        {
            try
            {
                if (File.Exists(SettingsFilePath))
                {
                    var json = File.ReadAllText(SettingsFilePath, Encoding.UTF8);
                    var dict = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
                    if (dict != null && dict.TryGetValue("SavePath", out var path) && !string.IsNullOrEmpty(path))
                        txtLocalPath.Text = path;
                }
            }
            catch { /* 설정 파일 오류 무시 */ }
        }

        private void SaveSavePath()
        {
            try
            {
                var dict = new Dictionary<string, string> { ["SavePath"] = txtLocalPath.Text.Trim() };
                var json = JsonSerializer.Serialize(dict, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SettingsFilePath, json, Encoding.UTF8);
            }
            catch { /* 저장 실패 무시 */ }
        }

        // ── 즐겨찾기 ─────────────────────────────────────────────
        private void LoadFavorites()
        {
            try
            {
                if (File.Exists(FavoritesFilePath))
                {
                    var json = File.ReadAllText(FavoritesFilePath, Encoding.UTF8);
                    _favorites = JsonSerializer.Deserialize<List<string>>(json) ?? new();
                }
            }
            catch { _favorites = new(); }
            RefreshFavoritesList();
        }

        private void SaveFavorites()
        {
            try
            {
                var json = JsonSerializer.Serialize(_favorites,
                    new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(FavoritesFilePath, json, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"즐겨찾기 저장 오류:\n{ex.Message}", "오류");
            }
        }

        private void RefreshFavoritesList()
        {
            listFavorites.Items.Clear();
            foreach (var path in _favorites)
                listFavorites.Items.Add(path);
        }

        private void BtnFavAdd_Click(object? sender, EventArgs e)
        {
            string? path = treeServer.SelectedNode?.Tag?.ToString();
            if (string.IsNullOrEmpty(path))
            {
                MessageBox.Show("트리에서 폴더를 먼저 선택하세요.", "알림");
                return;
            }
            if (_favorites.Contains(path))
            {
                MessageBox.Show("이미 등록된 경로입니다.", "알림");
                return;
            }
            _favorites.Add(path);
            SaveFavorites();
            RefreshFavoritesList();
        }

        private void BtnFavDelete_Click(object? sender, EventArgs e)
        {
            if (listFavorites.SelectedIndex < 0)
            {
                MessageBox.Show("삭제할 즐겨찾기를 선택하세요.", "알림");
                return;
            }
            _favorites.RemoveAt(listFavorites.SelectedIndex);
            SaveFavorites();
            RefreshFavoritesList();
        }

        private async void ListFavorites_DoubleClick(object? sender, EventArgs e)
        {
            if (listFavorites.SelectedItem is not string targetPath) return;
            if (_ftp == null) { MessageBox.Show("서버에 접속되어 있지 않습니다."); return; }

            await NavigateTreeToPathAsync(targetPath);
        }

        private async Task NavigateTreeToPathAsync(string targetPath)
        {
            // 경로를 세그먼트로 분할: "/pub/example/sub" → ["/", "pub", "example", "sub"]
            var segments = targetPath.Split('/', StringSplitOptions.RemoveEmptyEntries);

            // 루트 노드 찾기
            if (treeServer.Nodes.Count == 0) return;
            var currentNode = treeServer.Nodes[0]; // "/"

            // 루트 펼치기
            await ExpandNodeAsync(currentNode);

            // 각 세그먼트를 순서대로 탐색
            foreach (var seg in segments)
            {
                TreeNode? childNode = null;
                foreach (TreeNode n in currentNode.Nodes)
                {
                    if (n.Name == seg || n.Text == seg)
                    {
                        childNode = n;
                        break;
                    }
                }
                if (childNode == null) break;

                await ExpandNodeAsync(childNode);
                currentNode = childNode;
            }

            // 최종 노드 선택
            treeServer.SelectedNode = currentNode;
            currentNode.EnsureVisible();
        }

        private async Task ExpandNodeAsync(TreeNode node)
        {
            // 더미("...")가 있으면 실제 로드 필요
            if (node.Nodes.Count == 1 && node.Nodes[0].Text == "...")
            {
                node.Nodes.Clear();
                string path = node.Tag?.ToString() ?? "/";
                try
                {
                    var items = await GetListingCachedAsync(path);
                    foreach (var item in items
                        .Where(i => i.Type == FtpObjectType.Directory)
                        .OrderBy(i => i.Name))
                    {
                        var child = new TreeNode(item.Name) { Tag = item.FullName };
                        child.Nodes.Add(new TreeNode("..."));
                        node.Nodes.Add(child);
                    }
                }
                catch { /* 무시 – 상위에서 처리 */ }
            }
            node.Expand();
        }

        // ── 검색결과 더블클릭 → 폴더: 트리 이동 / 파일: 다운로드 ─
        private async void ListFiles_DoubleClick(object? sender, EventArgs e)
        {
            if (listFiles.SelectedItems.Count == 0) return;
            var lvi = listFiles.SelectedItems[0];
            if (lvi.Tag is not FtpListItem ftpItem) return;

            if (ftpItem.Type == FtpObjectType.Directory)
            {
                // 폴더 → 트리 네비게이션
                await NavigateTreeToPathAsync(ftpItem.FullName);
            }
            else if (ftpItem.Type == FtpObjectType.File)
            {
                // 파일 → 다운로드
                if (_ftp == null) { MessageBox.Show("서버에 접속되어 있지 않습니다."); return; }
                string localDir = txtLocalPath.Text.Trim();
                if (string.IsNullOrEmpty(localDir) || !Directory.Exists(localDir))
                {
                    MessageBox.Show("유효한 저장 경로를 먼저 선택하세요.", "알림");
                    return;
                }
                try
                {
                    string localFile = Path.Combine(localDir, ftpItem.Name);
                    lvi.SubItems[lvi.SubItems.Count - 1].Text = "다운로드 중...";
                    listFiles.Refresh();
                    await _ftp.DownloadFile(localFile, ftpItem.FullName, FtpLocalExists.Overwrite);
                    lvi.SubItems[lvi.SubItems.Count - 1].Text = "✔ 완료";
                    lvi.ForeColor = Color.Green;
                    MessageBox.Show($"다운로드 완료:\n{localFile}", "완료");
                }
                catch (Exception ex)
                {
                    lvi.SubItems[lvi.SubItems.Count - 1].Text = "오류";
                    lvi.ForeColor = Color.Red;
                    MessageBox.Show($"다운로드 오류:\n{ex.Message}", "오류");
                }
            }
        }

        // ── 검색결과 선택 → 경로 표시 ───────────────────────────
        private void ListFiles_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (listFiles.SelectedItems.Count == 0 || listFiles.SelectedItems[0].Tag is not FtpListItem ftpItem)
            {
                lblSelectedPath.Text = "";
                return;
            }
            string prefix = ftpItem.Type == FtpObjectType.Directory ? "📁 폴더 경로: " : "📄 파일 경로: ";
            lblSelectedPath.Text = prefix + ftpItem.FullName;
        }

        // ── 유틸 ─────────────────────────────────────────────────
        private static string FormatSize(long bytes)
        {
            if (bytes >= 1024L * 1024 * 1024) return $"{bytes / (1024.0 * 1024 * 1024):F2} GB";
            if (bytes >= 1024 * 1024)         return $"{bytes / (1024.0 * 1024):F2} MB";
            if (bytes >= 1024)                return $"{bytes / 1024.0:F1} KB";
            return $"{bytes} B";
        }
    }
}
