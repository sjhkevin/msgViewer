using Microsoft.Web.WebView2.WinForms;

namespace SamBQ.Forms
{
    partial class BrowserLoginForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            panelNav = new Panel();
            flowNav = new FlowLayoutPanel();
            btnBack = new Button();
            btnForward = new Button();
            btnRefresh = new Button();
            txtUrl = new TextBox();
            btnGo = new Button();
            panelBottom = new Panel();
            lblStatus = new Label();
            btnApply = new Button();
            webView = new WebView2();
            panelNav.SuspendLayout();
            flowNav.SuspendLayout();
            panelBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)webView).BeginInit();
            SuspendLayout();
            //
            // panelNav
            //
            panelNav.Controls.Add(txtUrl);
            panelNav.Controls.Add(flowNav);
            panelNav.Controls.Add(btnGo);
            panelNav.Dock = DockStyle.Top;
            panelNav.Location = new Point(0, 0);
            panelNav.Name = "panelNav";
            panelNav.Padding = new Padding(4);
            panelNav.Size = new Size(1100, 38);
            panelNav.TabIndex = 0;
            //
            // flowNav
            //
            flowNav.Controls.Add(btnBack);
            flowNav.Controls.Add(btnForward);
            flowNav.Controls.Add(btnRefresh);
            flowNav.Dock = DockStyle.Left;
            flowNav.Location = new Point(4, 4);
            flowNav.Name = "flowNav";
            flowNav.Size = new Size(120, 30);
            flowNav.TabIndex = 0;
            flowNav.WrapContents = false;
            //
            // btnBack
            //
            btnBack.Font = new Font("맑은 고딕", 10F, FontStyle.Bold);
            btnBack.Location = new Point(2, 2);
            btnBack.Margin = new Padding(2);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(34, 28);
            btnBack.TabIndex = 0;
            btnBack.Text = "←";
            btnBack.Click += BtnBack_Click;
            //
            // btnForward
            //
            btnForward.Font = new Font("맑은 고딕", 10F, FontStyle.Bold);
            btnForward.Location = new Point(40, 2);
            btnForward.Margin = new Padding(2);
            btnForward.Name = "btnForward";
            btnForward.Size = new Size(34, 28);
            btnForward.TabIndex = 1;
            btnForward.Text = "→";
            btnForward.Click += BtnForward_Click;
            //
            // btnRefresh
            //
            btnRefresh.Font = new Font("맑은 고딕", 9F);
            btnRefresh.Location = new Point(78, 2);
            btnRefresh.Margin = new Padding(2);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(34, 28);
            btnRefresh.TabIndex = 2;
            btnRefresh.Text = "🔄";
            btnRefresh.Click += BtnRefresh_Click;
            //
            // txtUrl
            //
            txtUrl.Dock = DockStyle.Fill;
            txtUrl.Font = new Font("맑은 고딕", 10F);
            txtUrl.Location = new Point(124, 4);
            txtUrl.Name = "txtUrl";
            txtUrl.Size = new Size(902, 25);
            txtUrl.TabIndex = 1;
            txtUrl.Text = "https://www.google.com";
            txtUrl.KeyDown += TxtUrl_KeyDown;
            //
            // btnGo
            //
            btnGo.BackColor = Color.FromArgb(0, 122, 204);
            btnGo.Dock = DockStyle.Right;
            btnGo.ForeColor = Color.White;
            btnGo.Location = new Point(1026, 4);
            btnGo.Name = "btnGo";
            btnGo.Size = new Size(70, 30);
            btnGo.TabIndex = 2;
            btnGo.Text = "이동";
            btnGo.UseVisualStyleBackColor = false;
            btnGo.Click += BtnGo_Click;
            //
            // panelBottom
            //
            panelBottom.Controls.Add(lblStatus);
            panelBottom.Controls.Add(btnApply);
            panelBottom.Dock = DockStyle.Bottom;
            panelBottom.Location = new Point(0, 662);
            panelBottom.Name = "panelBottom";
            panelBottom.Padding = new Padding(8);
            panelBottom.Size = new Size(1100, 48);
            panelBottom.TabIndex = 2;
            //
            // lblStatus
            //
            lblStatus.Dock = DockStyle.Fill;
            lblStatus.ForeColor = Color.DimGray;
            lblStatus.Location = new Point(8, 8);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(884, 32);
            lblStatus.TabIndex = 0;
            lblStatus.Text = "로그인할 사이트로 이동한 후 로그인하세요.";
            lblStatus.TextAlign = ContentAlignment.MiddleLeft;
            //
            // btnApply
            //
            btnApply.BackColor = Color.ForestGreen;
            btnApply.Dock = DockStyle.Right;
            btnApply.Font = new Font("맑은 고딕", 10F, FontStyle.Bold);
            btnApply.ForeColor = Color.White;
            btnApply.Location = new Point(892, 8);
            btnApply.Name = "btnApply";
            btnApply.Size = new Size(200, 32);
            btnApply.TabIndex = 1;
            btnApply.Text = "✔ 쿠키 적용 후 닫기";
            btnApply.UseVisualStyleBackColor = false;
            btnApply.Click += BtnApply_Click;
            //
            // webView
            //
            webView.AllowExternalDrop = true;
            webView.Dock = DockStyle.Fill;
            webView.Location = new Point(0, 38);
            webView.Name = "webView";
            webView.Size = new Size(1100, 624);
            webView.TabIndex = 1;
            //
            // BrowserLoginForm
            //
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1100, 710);
            Controls.Add(webView);
            Controls.Add(panelBottom);
            Controls.Add(panelNav);
            Name = "BrowserLoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "로그인 브라우저 — 로그인 후 [쿠키 적용 후 닫기] 클릭";
            panelNav.ResumeLayout(false);
            panelNav.PerformLayout();
            flowNav.ResumeLayout(false);
            panelBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)webView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelNav;
        private FlowLayoutPanel flowNav;
        private Button btnBack;
        private Button btnForward;
        private Button btnRefresh;
        private TextBox txtUrl;
        private Button btnGo;
        private WebView2 webView;
        private Panel panelBottom;
        private Label lblStatus;
        private Button btnApply;
    }
}
