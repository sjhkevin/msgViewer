using SamBQ.Models;
using System.Net;
using System.Text;

namespace SamBQ.Forms
{
    public partial class UrlDownloadPage : UserControl
    {
        private List<UrlDownloadItem> _items = new();
        private CancellationTokenSource? _cts;

        // ── 기본 HttpClient (쿠키 없음) ──
        private static readonly HttpClient _http = new HttpClient(
            new HttpClientHandler { AllowAutoRedirect = true })
        {
            Timeout = TimeSpan.FromSeconds(60)
        };

        // ── 인증 HttpClient (쿠키 포함) ──
        private CookieContainer? _cookieContainer;
        private HttpClient? _authenticatedHttp;

        private static readonly string UserAgent =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

        public UrlDownloadPage()
        {
            _http.DefaultRequestHeaders.UserAgent.ParseAdd(UserAgent);
            InitializeComponent();
        }

        // ── 로그인 브라우저 / 쿠키 ──────────────────────────────────
        private void BtnBrowser_Click(object? sender, EventArgs e)
        {
            using var form = new BrowserLoginForm();
            if (form.ShowDialog() == DialogResult.OK && form.ExtractedCookies.Count > 0)
            {
                ApplyCookies(form.ExtractedCookies);
            }
        }

        private void ApplyCookies(List<Cookie> cookies)
        {
            // 기존 인증 클라이언트 해제
            _authenticatedHttp?.Dispose();

            _cookieContainer = new CookieContainer();
            foreach (var c in cookies)
            {
                try { _cookieContainer.Add(c); }
                catch { /* 유효하지 않은 쿠키 건너뜀 */ }
            }

            var handler = new HttpClientHandler
            {
                CookieContainer = _cookieContainer,
                AllowAutoRedirect = true,
                UseCookies = true
            };
            _authenticatedHttp = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(60) };
            _authenticatedHttp.DefaultRequestHeaders.UserAgent.ParseAdd(UserAgent);

            lblCookieStatus.Text = $"✔ 쿠키 적용됨 ({cookies.Count}개)";
            lblCookieStatus.ForeColor = Color.ForestGreen;
        }

        /// <summary>쿠키가 적용된 HttpClient 반환 (없으면 기본 HttpClient)</summary>
        private HttpClient GetHttpClient() => _authenticatedHttp ?? _http;

        // ── 이벤트 핸들러 ─────────────────────────────────────────
        private void BtnStop_Click(object? sender, EventArgs e) => _cts?.Cancel();

        private void BtnBrowse_Click(object? sender, EventArgs e)
        {
            using var dlg = new FolderBrowserDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
                txtSavePath.Text = dlg.SelectedPath;
        }

        private void BtnOpenFolder_Click(object? sender, EventArgs e)
        {
            var path = txtSavePath.Text.Trim();
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path))
            {
                MessageBox.Show("유효한 저장 경로를 먼저 선택하세요.", "알림");
                return;
            }
            System.Diagnostics.Process.Start("explorer.exe", path);
        }

        private void BtnCsvUpload_Click(object? sender, EventArgs e)
        {
            using var dlg = new OpenFileDialog { Filter = "텍스트 파일|*.txt" };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            _items = ParseCsv(dlg.FileName);
            lblRowCount.Text = $"업로드 행수: {_items.Count}";
            RefreshList();
            MessageBox.Show($"CSV 로드 완료: {_items.Count}개 항목", "알림");
        }

        private static List<UrlDownloadItem> ParseCsv(string path)
        {
            var list = new List<UrlDownloadItem>();
            // FileShare.ReadWrite → Excel 등에서 파일을 열고 있어도 읽기 가능
            string[] lines;
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var sr = new StreamReader(fs, Encoding.UTF8))
            {
                lines = sr.ReadToEnd().Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            }
            foreach (var line in lines.Skip(1))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                var parts = line.Split("^^");
                list.Add(new UrlDownloadItem
                {
                    Url         = parts.Length > 0 ? parts[0].Trim() : "",
                    NewFileName = parts.Length > 1 ? parts[1].Trim() : "",
                    Index       = parts.Length > 2 ? parts[2].Trim() : ""
                });
            }
            return list;
        }

        private void RefreshList()
        {
            listItems.Items.Clear();
            foreach (var item in _items)
            {
                var lvi = new ListViewItem(item.Index);
                lvi.SubItems.Add(item.Url);
                lvi.SubItems.Add(item.NewFileName);
                lvi.SubItems.Add(item.Status);
                listItems.Items.Add(lvi);
            }
        }

        private void UpdateRow(int index)
        {
            if (index < 0 || index >= listItems.Items.Count) return;
            listItems.Items[index].SubItems[3].Text = _items[index].Status;
        }

        private async void BtnStart_Click(object? sender, EventArgs e)
        {
            if (_items.Count == 0)              { MessageBox.Show("CSV 파일을 먼저 업로드하세요."); return; }
            if (string.IsNullOrEmpty(txtSavePath.Text)) { MessageBox.Show("저장 경로를 선택하세요."); return; }

            _cts = new CancellationTokenSource();
            btnStart.Enabled = false;
            progressBar.Maximum = _items.Count;
            progressBar.Value = 0;

            // lblFmt를 진행 상태 표시용으로 전환
            string origFmtText = lblFmt.Text;
            var origFmtColor = lblFmt.ForeColor;
            var origFmtFont = lblFmt.Font;
            lblFmt.Font = new Font(lblFmt.Font.FontFamily, 9F, FontStyle.Bold);
            lblFmt.ForeColor = Color.FromArgb(0, 122, 204);

            double intervalMs = (double)numInterval.Value * 1000;

            for (int i = 0; i < _items.Count; i++)
            {
                if (_cts.Token.IsCancellationRequested) break;

                var item = _items[i];
                item.Status = "다운중...";
                UpdateRow(i);

                // 파일명 표시
                string displayName = !string.IsNullOrEmpty(item.NewFileName)
                    ? item.NewFileName
                    : Path.GetFileName(new Uri(item.Url).LocalPath);
                lblFmt.Text = $"▶ [{i + 1}/{_items.Count}] 다운로드 중: {displayName}";
                lblFmt.Refresh();

                try
                {
                    await DownloadUrlAsync(item, txtSavePath.Text);
                    item.Status = "완료";
                }
                catch (Exception ex)
                {
                    item.Status = "오류";
                    System.Diagnostics.Debug.WriteLine($"[{item.Index}] {ex.Message}");
                }

                UpdateRow(i);
                progressBar.Value = i + 1;
                lblProgress.Text = $"{i + 1} / {_items.Count}";
                await Task.Delay((int)intervalMs);
            }

            // lblFmt 원래 상태로 복원
            lblFmt.Text = origFmtText;
            lblFmt.ForeColor = origFmtColor;
            lblFmt.Font = origFmtFont;
            btnStart.Enabled = true;
            MessageBox.Show("다운로드 처리가 완료되었습니다.", "완료");
        }

        private async Task DownloadUrlAsync(UrlDownloadItem item, string saveDir)
        {
            if (string.IsNullOrEmpty(item.Url))
                throw new Exception("URL이 비어 있습니다.");

            var client = GetHttpClient();
            var bytes = await client.GetByteArrayAsync(item.Url);

            // 저장 파일명 결정
            string fileName = item.NewFileName;
            if (string.IsNullOrEmpty(fileName))
            {
                var uri = new Uri(item.Url);
                fileName = Path.GetFileName(uri.LocalPath);
                if (string.IsNullOrEmpty(fileName))
                    fileName = $"download_{item.Index}";
            }

            // 확장자가 없으면 URL에서 추론
            if (!Path.HasExtension(fileName))
            {
                var urlLower = new Uri(item.Url).LocalPath.ToLowerInvariant();
                var ext = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".pdf", ".zip" }
                    .FirstOrDefault(e => urlLower.Contains(e)) ?? ".bin";
                fileName += ext;
            }

            var dest = Path.Combine(saveDir, fileName);
            await File.WriteAllBytesAsync(dest, bytes);
        }
    }
}
