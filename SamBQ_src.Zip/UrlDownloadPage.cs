using SamBQ.Models;
using System.Text;

namespace SamBQ.Forms
{
    public partial class UrlDownloadPage : UserControl
    {
        private List<UrlDownloadItem> _items = new();
        private CancellationTokenSource? _cts;

        private static readonly HttpClient _http = new HttpClient(
            new HttpClientHandler { AllowAutoRedirect = true })
        {
            Timeout = TimeSpan.FromSeconds(60)
        };

        public UrlDownloadPage()
        {
            _http.DefaultRequestHeaders.UserAgent.ParseAdd(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
            InitializeComponent();
        }

        // ── 이벤트 핸들러 ─────────────────────────────────────────
        private void BtnStop_Click(object? sender, EventArgs e) => _cts?.Cancel();

        private void BtnBrowse_Click(object? sender, EventArgs e)
        {
            using var dlg = new FolderBrowserDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
                txtSavePath.Text = dlg.SelectedPath;
        }

        private void BtnOpenFolder_Click(object? sender, EventArgs e)
        {
            var path = txtSavePath.Text.Trim();
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path))
            {
                MessageBox.Show("유효한 저장 경로를 먼저 선택하세요.", "알림");
                return;
            }
            System.Diagnostics.Process.Start("explorer.exe", path);
        }

        private void BtnCsvUpload_Click(object? sender, EventArgs e)
        {
            using var dlg = new OpenFileDialog { Filter = "CSV 파일|*.csv" };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            _items = ParseCsv(dlg.FileName);
            lblRowCount.Text = $"업로드 행수: {_items.Count}";
            RefreshList();
            MessageBox.Show($"CSV 로드 완료: {_items.Count}개 항목", "알림");
        }

        private static List<UrlDownloadItem> ParseCsv(string path)
        {
            var list = new List<UrlDownloadItem>();
            // FileShare.ReadWrite → Excel 등에서 파일을 열고 있어도 읽기 가능
            string[] lines;
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var sr = new StreamReader(fs, Encoding.UTF8))
            {
                lines = sr.ReadToEnd().Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            }
            foreach (var line in lines.Skip(1))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                var parts = line.Split(',');
                list.Add(new UrlDownloadItem
                {
                    Url         = parts.Length > 0 ? parts[0].Trim() : "",
                    NewFileName = parts.Length > 1 ? parts[1].Trim() : "",
                    Index       = parts.Length > 2 ? parts[2].Trim() : ""
                });
            }
            return list;
        }

        private void RefreshList()
        {
            listItems.Items.Clear();
            foreach (var item in _items)
            {
                var lvi = new ListViewItem(item.Index);
                lvi.SubItems.Add(item.Url);
                lvi.SubItems.Add(item.NewFileName);
                lvi.SubItems.Add(item.Status);
                listItems.Items.Add(lvi);
            }
        }

        private void UpdateRow(int index)
        {
            if (index < 0 || index >= listItems.Items.Count) return;
            listItems.Items[index].SubItems[3].Text = _items[index].Status;
        }

        private async void BtnStart_Click(object? sender, EventArgs e)
        {
            if (_items.Count == 0)              { MessageBox.Show("CSV 파일을 먼저 업로드하세요."); return; }
            if (string.IsNullOrEmpty(txtSavePath.Text)) { MessageBox.Show("저장 경로를 선택하세요."); return; }

            _cts = new CancellationTokenSource();
            btnStart.Enabled = false;
            progressBar.Maximum = _items.Count;
            progressBar.Value = 0;
            double intervalMs = (double)numInterval.Value * 1000;

            for (int i = 0; i < _items.Count; i++)
            {
                if (_cts.Token.IsCancellationRequested) break;

                var item = _items[i];
                item.Status = "다운중...";
                UpdateRow(i);

                try
                {
                    await DownloadUrlAsync(item, txtSavePath.Text);
                    item.Status = "완료";
                }
                catch (Exception ex)
                {
                    item.Status = "오류";
                    System.Diagnostics.Debug.WriteLine($"[{item.Index}] {ex.Message}");
                }

                UpdateRow(i);
                progressBar.Value = i + 1;
                lblProgress.Text = $"{i + 1} / {_items.Count}";
                Application.DoEvents();
                await Task.Delay((int)intervalMs);
            }

            btnStart.Enabled = true;
            MessageBox.Show("다운로드 처리가 완료되었습니다.", "완료");
        }

        private static async Task DownloadUrlAsync(UrlDownloadItem item, string saveDir)
        {
            if (string.IsNullOrEmpty(item.Url))
                throw new Exception("URL이 비어 있습니다.");

            var bytes = await _http.GetByteArrayAsync(item.Url);

            // 저장 파일명 결정
            string fileName = item.NewFileName;
            if (string.IsNullOrEmpty(fileName))
            {
                var uri = new Uri(item.Url);
                fileName = Path.GetFileName(uri.LocalPath);
                if (string.IsNullOrEmpty(fileName))
                    fileName = $"download_{item.Index}";
            }

            // 확장자가 없으면 URL에서 추론
            if (!Path.HasExtension(fileName))
            {
                var urlLower = new Uri(item.Url).LocalPath.ToLowerInvariant();
                var ext = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".pdf", ".zip" }
                    .FirstOrDefault(e => urlLower.Contains(e)) ?? ".bin";
                fileName += ext;
            }

            var dest = Path.Combine(saveDir, fileName);
            await File.WriteAllBytesAsync(dest, bytes);
        }
    }
}
