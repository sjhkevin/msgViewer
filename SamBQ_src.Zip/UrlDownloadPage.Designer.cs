namespace SamBQ.Forms
{
    partial class UrlDownloadPage
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        private void InitializeComponent()
        {
            panelTop = new Panel();
            panelProgress = new Panel();
            progressBar = new ProgressBar();
            lblProgress = new Label();
            lblFmt = new Label();
            flowRow2 = new FlowLayoutPanel();
            lblSave = new Label();
            txtSavePath = new TextBox();
            btnBrowse = new Button();
            btnOpenFolder = new Button();
            flowRow1 = new FlowLayoutPanel();
            lblInterval = new Label();
            numInterval = new NumericUpDown();
            btnCsvUpload = new Button();
            lblRowCount = new Label();
            btnStart = new Button();
            btnStop = new Button();
            btnBrowser = new Button();
            lblCookieStatus = new Label();
            listItems = new ListView();
            colIndex = new ColumnHeader();
            colUrl = new ColumnHeader();
            colFileName = new ColumnHeader();
            colStatus = new ColumnHeader();
            panelTop.SuspendLayout();
            panelProgress.SuspendLayout();
            flowRow2.SuspendLayout();
            flowRow1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numInterval).BeginInit();
            SuspendLayout();
            // 
            // panelTop
            // 
            panelTop.Controls.Add(panelProgress);
            panelTop.Controls.Add(lblFmt);
            panelTop.Controls.Add(flowRow2);
            panelTop.Controls.Add(flowRow1);
            panelTop.Dock = DockStyle.Top;
            panelTop.Location = new Point(0, 0);
            panelTop.Name = "panelTop";
            panelTop.Padding = new Padding(6);
            panelTop.Size = new Size(1000, 130);
            panelTop.TabIndex = 0;
            // 
            // panelProgress
            // 
            panelProgress.Controls.Add(progressBar);
            panelProgress.Controls.Add(lblProgress);
            panelProgress.Dock = DockStyle.Top;
            panelProgress.Location = new Point(6, 99);
            panelProgress.Name = "panelProgress";
            panelProgress.Padding = new Padding(0, 4, 0, 4);
            panelProgress.Size = new Size(988, 30);
            panelProgress.TabIndex = 3;
            // 
            // progressBar
            // 
            progressBar.Dock = DockStyle.Fill;
            progressBar.Location = new Point(0, 4);
            progressBar.Name = "progressBar";
            progressBar.Size = new Size(908, 22);
            progressBar.TabIndex = 0;
            // 
            // lblProgress
            // 
            lblProgress.Dock = DockStyle.Right;
            lblProgress.Location = new Point(908, 4);
            lblProgress.Name = "lblProgress";
            lblProgress.Padding = new Padding(6, 0, 0, 0);
            lblProgress.Size = new Size(80, 22);
            lblProgress.TabIndex = 1;
            lblProgress.Text = "0 / 0";
            lblProgress.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblFmt
            // 
            lblFmt.Dock = DockStyle.Top;
            lblFmt.ForeColor = Color.DarkOrange;
            lblFmt.Location = new Point(6, 76);
            lblFmt.Name = "lblFmt";
            lblFmt.Padding = new Padding(0, 4, 0, 4);
            lblFmt.Size = new Size(988, 23);
            lblFmt.TabIndex = 2;
            lblFmt.Text = "TXT 형식: 대상URL^^변경파일명^^index(참고용)";
            // 
            // flowRow2
            // 
            flowRow2.Controls.Add(lblSave);
            flowRow2.Controls.Add(txtSavePath);
            flowRow2.Controls.Add(btnBrowse);
            flowRow2.Controls.Add(btnOpenFolder);
            flowRow2.Dock = DockStyle.Top;
            flowRow2.Location = new Point(6, 42);
            flowRow2.Name = "flowRow2";
            flowRow2.Size = new Size(988, 34);
            flowRow2.TabIndex = 1;
            flowRow2.WrapContents = false;
            // 
            // lblSave
            // 
            lblSave.AutoSize = true;
            lblSave.Location = new Point(3, 8);
            lblSave.Margin = new Padding(3, 8, 3, 3);
            lblSave.Name = "lblSave";
            lblSave.Size = new Size(62, 15);
            lblSave.TabIndex = 0;
            lblSave.Text = "저장 경로:";
            // 
            // txtSavePath
            // 
            txtSavePath.Location = new Point(71, 5);
            txtSavePath.Margin = new Padding(3, 5, 3, 3);
            txtSavePath.Name = "txtSavePath";
            txtSavePath.Size = new Size(641, 23);
            txtSavePath.TabIndex = 1;
            // 
            // btnBrowse
            // 
            btnBrowse.Location = new Point(718, 4);
            btnBrowse.Margin = new Padding(3, 4, 3, 3);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(145, 26);
            btnBrowse.TabIndex = 2;
            btnBrowse.Text = "폴더 선택";
            btnBrowse.Click += BtnBrowse_Click;
            // 
            // btnOpenFolder
            // 
            btnOpenFolder.Location = new Point(869, 4);
            btnOpenFolder.Margin = new Padding(3, 4, 3, 3);
            btnOpenFolder.Name = "btnOpenFolder";
            btnOpenFolder.Size = new Size(85, 26);
            btnOpenFolder.TabIndex = 3;
            btnOpenFolder.Text = "탐색기 열기";
            btnOpenFolder.Click += BtnOpenFolder_Click;
            // 
            // flowRow1
            // 
            flowRow1.Controls.Add(lblInterval);
            flowRow1.Controls.Add(numInterval);
            flowRow1.Controls.Add(btnCsvUpload);
            flowRow1.Controls.Add(lblRowCount);
            flowRow1.Controls.Add(btnStart);
            flowRow1.Controls.Add(btnStop);
            flowRow1.Controls.Add(btnBrowser);
            flowRow1.Controls.Add(lblCookieStatus);
            flowRow1.Dock = DockStyle.Top;
            flowRow1.Location = new Point(6, 6);
            flowRow1.Name = "flowRow1";
            flowRow1.Size = new Size(988, 36);
            flowRow1.TabIndex = 0;
            flowRow1.WrapContents = false;
            // 
            // lblInterval
            // 
            lblInterval.AutoSize = true;
            lblInterval.Location = new Point(3, 10);
            lblInterval.Margin = new Padding(3, 10, 3, 3);
            lblInterval.Name = "lblInterval";
            lblInterval.Size = new Size(82, 15);
            lblInterval.TabIndex = 0;
            lblInterval.Text = "다운 간격(초):";
            // 
            // numInterval
            // 
            numInterval.DecimalPlaces = 1;
            numInterval.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
            numInterval.Location = new Point(91, 6);
            numInterval.Margin = new Padding(3, 6, 3, 3);
            numInterval.Maximum = new decimal(new int[] { 60, 0, 0, 0 });
            numInterval.Minimum = new decimal(new int[] { 1, 0, 0, 65536 });
            numInterval.Name = "numInterval";
            numInterval.Size = new Size(75, 23);
            numInterval.TabIndex = 1;
            numInterval.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // btnCsvUpload
            // 
            btnCsvUpload.BackColor = Color.FromArgb(0, 122, 204);
            btnCsvUpload.ForeColor = Color.White;
            btnCsvUpload.Location = new Point(181, 4);
            btnCsvUpload.Margin = new Padding(12, 4, 3, 3);
            btnCsvUpload.Name = "btnCsvUpload";
            btnCsvUpload.Size = new Size(141, 28);
            btnCsvUpload.TabIndex = 2;
            btnCsvUpload.Text = "대상 목록 파일 선택";
            btnCsvUpload.UseVisualStyleBackColor = false;
            btnCsvUpload.Click += BtnCsvUpload_Click;
            // 
            // lblRowCount
            // 
            lblRowCount.AutoSize = true;
            lblRowCount.Location = new Point(328, 10);
            lblRowCount.Margin = new Padding(3, 10, 3, 3);
            lblRowCount.Name = "lblRowCount";
            lblRowCount.Size = new Size(85, 15);
            lblRowCount.TabIndex = 3;
            lblRowCount.Text = "업로드 행수: 0";
            // 
            // btnStart
            // 
            btnStart.BackColor = Color.SteelBlue;
            btnStart.ForeColor = Color.White;
            btnStart.Location = new Point(428, 4);
            btnStart.Margin = new Padding(12, 4, 3, 3);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(130, 28);
            btnStart.TabIndex = 4;
            btnStart.Text = "▶ 다운로드 시작";
            btnStart.UseVisualStyleBackColor = false;
            btnStart.Click += BtnStart_Click;
            // 
            // btnStop
            // 
            btnStop.BackColor = Color.Tomato;
            btnStop.ForeColor = Color.White;
            btnStop.Location = new Point(564, 4);
            btnStop.Margin = new Padding(3, 4, 3, 3);
            btnStop.Name = "btnStop";
            btnStop.Size = new Size(75, 28);
            btnStop.TabIndex = 5;
            btnStop.Text = "■ 중지";
            btnStop.UseVisualStyleBackColor = false;
            btnStop.Click += BtnStop_Click;
            // 
            // btnBrowser
            // 
            btnBrowser.BackColor = Color.FromArgb(138, 43, 226);
            btnBrowser.FlatAppearance.BorderSize = 0;
            btnBrowser.FlatStyle = FlatStyle.Flat;
            btnBrowser.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            btnBrowser.ForeColor = Color.White;
            btnBrowser.Location = new Point(662, 4);
            btnBrowser.Margin = new Padding(20, 4, 3, 3);
            btnBrowser.Name = "btnBrowser";
            btnBrowser.Size = new Size(120, 28);
            btnBrowser.TabIndex = 6;
            btnBrowser.Text = "🌐 로그인 브라우저";
            btnBrowser.UseVisualStyleBackColor = false;
            btnBrowser.Click += BtnBrowser_Click;
            // 
            // lblCookieStatus
            // 
            lblCookieStatus.AutoSize = true;
            lblCookieStatus.ForeColor = Color.Gray;
            lblCookieStatus.Location = new Point(788, 10);
            lblCookieStatus.Margin = new Padding(3, 10, 3, 3);
            lblCookieStatus.Name = "lblCookieStatus";
            lblCookieStatus.Size = new Size(74, 15);
            lblCookieStatus.TabIndex = 7;
            lblCookieStatus.Text = "쿠키: 미적용";
            // 
            // listItems
            // 
            listItems.Columns.AddRange(new ColumnHeader[] { colIndex, colUrl, colFileName, colStatus });
            listItems.Dock = DockStyle.Fill;
            listItems.FullRowSelect = true;
            listItems.Location = new Point(0, 130);
            listItems.Name = "listItems";
            listItems.Size = new Size(1000, 470);
            listItems.TabIndex = 1;
            listItems.UseCompatibleStateImageBehavior = false;
            listItems.View = View.Details;
            // 
            // colIndex
            // 
            colIndex.Text = "Index";
            colIndex.Width = 70;
            // 
            // colUrl
            // 
            colUrl.Text = "대상 URL";
            colUrl.Width = 460;
            // 
            // colFileName
            // 
            colFileName.Text = "저장 파일명";
            colFileName.Width = 200;
            // 
            // colStatus
            // 
            colStatus.Text = "상태";
            colStatus.Width = 120;
            // 
            // UrlDownloadPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(listItems);
            Controls.Add(panelTop);
            Name = "UrlDownloadPage";
            Size = new Size(1000, 600);
            panelTop.ResumeLayout(false);
            panelProgress.ResumeLayout(false);
            flowRow2.ResumeLayout(false);
            flowRow2.PerformLayout();
            flowRow1.ResumeLayout(false);
            flowRow1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numInterval).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelTop;
        private FlowLayoutPanel flowRow1;
        private Label lblInterval;
        private NumericUpDown numInterval;
        private Button btnCsvUpload;
        private Label lblRowCount;
        private Button btnStart;
        private Button btnStop;
        private Button btnBrowser;
        private Label lblCookieStatus;
        private FlowLayoutPanel flowRow2;
        private Label lblSave;
        private TextBox txtSavePath;
        private Button btnBrowse;
        private Button btnOpenFolder;
        private Label lblFmt;
        private Panel panelProgress;
        private ProgressBar progressBar;
        private Label lblProgress;
        private ListView listItems;
        private ColumnHeader colIndex;
        private ColumnHeader colUrl;
        private ColumnHeader colFileName;
        private ColumnHeader colStatus;
    }
}
