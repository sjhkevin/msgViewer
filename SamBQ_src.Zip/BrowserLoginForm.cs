using Microsoft.Web.WebView2.Core;
using System.Net;

namespace SamBQ.Forms
{
    public partial class BrowserLoginForm : Form
    {
        /// <summary>쿠키 적용 후 닫기 시 추출된 쿠키 목록</summary>
        public List<Cookie> ExtractedCookies { get; private set; } = new();

        private static readonly string WebViewDataFolder =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "WebView2Data");

        public BrowserLoginForm()
        {
            InitializeComponent();
            InitializeWebViewAsync();
        }

        private async void InitializeWebViewAsync()
        {
            try
            {
                var env = await CoreWebView2Environment.CreateAsync(
                    userDataFolder: WebViewDataFolder);
                await webView.EnsureCoreWebView2Async(env);

                // URL 변경 시 주소창 동기화
                webView.CoreWebView2.SourceChanged += (s, e) =>
                {
                    if (webView.CoreWebView2 != null)
                        txtUrl.Text = webView.CoreWebView2.Source;
                };

                // 페이지 타이틀 변경 시 폼 타이틀 동기화
                webView.CoreWebView2.DocumentTitleChanged += (s, e) =>
                {
                    this.Text = $"로그인 브라우저 — {webView.CoreWebView2.DocumentTitle}";
                };

                // 네비게이션 완료 시 상태 표시
                webView.CoreWebView2.NavigationCompleted += (s, e) =>
                {
                    lblStatus.Text = e.IsSuccess
                        ? $"페이지 로드 완료. 로그인 후 [쿠키 적용 후 닫기] 를 클릭하세요."
                        : $"페이지 로드 실패 (코드: {e.WebErrorStatus})";
                };

                // 초기 페이지로 이동
                webView.CoreWebView2.Navigate("https://www.google.com");
            }
            catch (Exception ex)
            {
                lblStatus.Text = $"WebView2 초기화 오류: {ex.Message}";
                lblStatus.ForeColor = Color.Red;
                MessageBox.Show(
                    $"WebView2를 초기화할 수 없습니다.\n\n" +
                    $"WebView2 Runtime이 설치되어 있는지 확인하세요.\n" +
                    $"(Windows 10/11은 보통 기본 설치됨)\n\n" +
                    $"오류: {ex.Message}",
                    "WebView2 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ── 네비게이션 버튼들 ──────────────────────────────────────
        private void BtnBack_Click(object? sender, EventArgs e)
        {
            if (webView.CoreWebView2?.CanGoBack == true)
                webView.CoreWebView2.GoBack();
        }

        private void BtnForward_Click(object? sender, EventArgs e)
        {
            if (webView.CoreWebView2?.CanGoForward == true)
                webView.CoreWebView2.GoForward();
        }

        private void BtnRefresh_Click(object? sender, EventArgs e)
        {
            webView.CoreWebView2?.Reload();
        }

        private void BtnGo_Click(object? sender, EventArgs e)
        {
            NavigateToUrl();
        }

        private void TxtUrl_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                NavigateToUrl();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        private void NavigateToUrl()
        {
            string url = txtUrl.Text.Trim();
            if (string.IsNullOrEmpty(url)) return;

            // http/https 없으면 자동 추가
            if (!url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
                !url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                url = "https://" + url;
            }
            webView.CoreWebView2?.Navigate(url);
        }

        // ── 쿠키 추출 후 닫기 ─────────────────────────────────────
        private async void BtnApply_Click(object? sender, EventArgs e)
        {
            if (webView.CoreWebView2 == null)
            {
                MessageBox.Show("브라우저가 아직 초기화되지 않았습니다.", "알림");
                return;
            }

            try
            {
                btnApply.Enabled = false;
                lblStatus.Text = "쿠키 추출 중...";

                var cookies = await webView.CoreWebView2.CookieManager.GetCookiesAsync("");
                ExtractedCookies.Clear();

                foreach (var c in cookies)
                {
                    try
                    {
                        var cookie = new Cookie(c.Name, c.Value, c.Path, c.Domain);
                        cookie.Secure = c.IsSecure;
                        cookie.HttpOnly = c.IsHttpOnly;
                        if (c.Expires.Year > 1970)
                            cookie.Expires = c.Expires;
                        ExtractedCookies.Add(cookie);
                    }
                    catch
                    {
                        // 변환 실패한 쿠키는 건너뜀
                    }
                }

                lblStatus.Text = $"✔ 쿠키 {ExtractedCookies.Count}개 추출 완료";
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                lblStatus.Text = $"쿠키 추출 오류: {ex.Message}";
                lblStatus.ForeColor = Color.Red;
                btnApply.Enabled = true;
            }
        }
    }
}
