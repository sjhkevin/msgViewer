using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace SamBQ
{
    /// <summary>
    /// 앱 아이콘을 프로그래밍 방식으로 생성합니다.
    /// 디자인: 진한 블루→시안 그라데이션 배경 + 흰색 굵은 "B" + 그림자
    /// </summary>
    public static class AppIcon
    {
        private static readonly Color ColorTop = Color.FromArgb(13, 71, 161);     // Deep Blue
        private static readonly Color ColorBottom = Color.FromArgb(0, 172, 193);  // Bright Cyan
        private static readonly Color ColorAccent = Color.FromArgb(0, 229, 255);  // Neon Cyan

        /// <summary>Icon 객체를 생성하여 반환합니다 (256x256).</summary>
        public static Icon Create()
        {
            using var bmp = DrawIcon(256);
            var hIcon = bmp.GetHicon();
            return Icon.FromHandle(hIcon);
        }

        /// <summary>멀티 사이즈 .ico 파일을 저장합니다.</summary>
        public static void SaveToFile(string path)
        {
            int[] sizes = { 16, 24, 32, 48, 64, 128, 256 };
            var pngDataList = new List<byte[]>();

            foreach (int size in sizes)
            {
                using var bmp = DrawIcon(size);
                using var ms = new MemoryStream();
                bmp.Save(ms, ImageFormat.Png);
                pngDataList.Add(ms.ToArray());
            }

            // ICO 파일 포맷 작성
            using var fs = new FileStream(path, FileMode.Create);
            using var bw = new BinaryWriter(fs);

            // Header
            bw.Write((short)0);               // Reserved
            bw.Write((short)1);               // Type: 1 = Icon
            bw.Write((short)sizes.Length);     // Image count

            // Directory entries
            int dataOffset = 6 + (sizes.Length * 16);
            for (int i = 0; i < sizes.Length; i++)
            {
                byte w = (byte)(sizes[i] < 256 ? sizes[i] : 0); // 256 → 0
                byte h = w;
                bw.Write(w);                  // Width
                bw.Write(h);                  // Height
                bw.Write((byte)0);            // Color palette
                bw.Write((byte)0);            // Reserved
                bw.Write((short)1);           // Color planes
                bw.Write((short)32);          // Bits per pixel
                bw.Write(pngDataList[i].Length); // Data size
                bw.Write(dataOffset);         // Data offset
                dataOffset += pngDataList[i].Length;
            }

            // Image data (PNG)
            foreach (var png in pngDataList)
                bw.Write(png);
        }

        private static Bitmap DrawIcon(int size)
        {
            var bmp = new Bitmap(size, size, PixelFormat.Format32bppArgb);
            using var g = Graphics.FromImage(bmp);
            g.SmoothingMode = SmoothingMode.HighQuality;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            float s = size;
            float pad = s * 0.02f;
            var rect = new RectangleF(pad, pad, s - pad * 2, s - pad * 2);
            float radius = s * 0.20f;

            // ── 1. 배경 그라데이션 (좌상→우하 대각선) ──
            using var bgPath = RoundedRectPath(rect, radius);
            using var bgBrush = new LinearGradientBrush(
                new PointF(0, 0), new PointF(s, s),
                ColorTop, ColorBottom);
            g.FillPath(bgBrush, bgPath);

            // ── 2. 하이라이트 (상단 밝은 빛 효과) ──
            var highlightRect = new RectangleF(pad, pad, rect.Width, rect.Height * 0.5f);
            using var highlightPath = RoundedRectPath(highlightRect, radius);
            using var highlightBrush = new LinearGradientBrush(
                highlightRect,
                Color.FromArgb(60, 255, 255, 255),
                Color.FromArgb(0, 255, 255, 255),
                90f);
            g.FillPath(highlightBrush, highlightPath);

            // ── 3. 하단 엣지 라인 (시안 액센트) ──
            using var accentPen = new Pen(Color.FromArgb(100, ColorAccent), Math.Max(1f, s * 0.015f));
            g.DrawPath(accentPen, bgPath);

            // ── 4. 텍스트 "B" ──
            float fontSize = s * 0.62f;
            using var font = new Font("Arial", fontSize, FontStyle.Bold, GraphicsUnit.Pixel);
            var sf = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            // "B" 위치 (약간 위로 보정)
            var textRect = new RectangleF(0, -s * 0.02f, s, s);

            // 그림자 (어두운)
            float shadowOff = Math.Max(1f, s * 0.035f);
            var shadowRect = textRect;
            shadowRect.Offset(shadowOff, shadowOff);
            using var shadowBrush = new SolidBrush(Color.FromArgb(80, 0, 0, 0));
            g.DrawString("B", font, shadowBrush, shadowRect, sf);

            // 메인 "B" (흰색)
            using var textBrush = new SolidBrush(Color.White);
            g.DrawString("B", font, textBrush, textRect, sf);

            // 밝은 하이라이트 (위쪽 살짝)
            var hlRect = textRect;
            hlRect.Offset(0, -Math.Max(0.5f, s * 0.01f));
            using var hlBrush = new SolidBrush(Color.FromArgb(40, 255, 255, 255));
            g.DrawString("B", font, hlBrush, hlRect, sf);

            return bmp;
        }

        private static GraphicsPath RoundedRectPath(RectangleF rect, float radius)
        {
            float d = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}
