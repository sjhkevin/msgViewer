namespace SamBQ;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        // 아이콘 파일이 없으면 자동 생성 (exe 아이콘용)
        var icoPath = Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "app.ico");
        if (!File.Exists(icoPath))
        {
            try { AppIcon.SaveToFile(icoPath); }
            catch { /* 첫 실행 시 생성 실패해도 무시 */ }
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainForm());
    }
}
