using SamBQ.Forms;

namespace SamBQ
{
    public class MainForm : Form
    {
        private TabControl tabMain = null!;
        private FtpDownloadPage ftpPage = null!;
        private TabPage tabFtp;
        private TabPage tabUrl;
        private UrlDownloadPage urlPage = null!;

        public MainForm()
        {
            InitializeComponent();
            this.Icon = AppIcon.Create();
        }

        private void InitializeComponent()
        {
            tabMain = new TabControl();
            tabFtp = new TabPage();
            ftpPage = new FtpDownloadPage();
            tabUrl = new TabPage();
            urlPage = new UrlDownloadPage();
            tabMain.SuspendLayout();
            tabFtp.SuspendLayout();
            tabUrl.SuspendLayout();
            SuspendLayout();
            // 
            // tabMain
            // 
            tabMain.Controls.Add(tabFtp);
            tabMain.Controls.Add(tabUrl);
            tabMain.Dock = DockStyle.Fill;
            tabMain.Location = new Point(0, 0);
            tabMain.Name = "tabMain";
            tabMain.SelectedIndex = 0;
            tabMain.Size = new Size(1184, 761);
            tabMain.TabIndex = 0;
            // 
            // tabFtp
            // 
            tabFtp.Controls.Add(ftpPage);
            tabFtp.Location = new Point(4, 24);
            tabFtp.Name = "tabFtp";
            tabFtp.Size = new Size(1176, 733);
            tabFtp.TabIndex = 0;
            tabFtp.Text = "  📁  파일서버 다운로드  ";
            // 
            // ftpPage
            // 
            ftpPage.Dock = DockStyle.Fill;
            ftpPage.Location = new Point(0, 0);
            ftpPage.Name = "ftpPage";
            ftpPage.Size = new Size(1176, 733);
            ftpPage.TabIndex = 0;
            // 
            // tabUrl
            // 
            tabUrl.Controls.Add(urlPage);
            tabUrl.Location = new Point(4, 24);
            tabUrl.Name = "tabUrl";
            tabUrl.Size = new Size(1176, 733);
            tabUrl.TabIndex = 1;
            tabUrl.Text = "  🌐  URL 다운로드  ";
            // 
            // urlPage
            // 
            urlPage.Dock = DockStyle.Fill;
            urlPage.Location = new Point(0, 0);
            urlPage.Name = "urlPage";
            urlPage.Size = new Size(1176, 733);
            urlPage.TabIndex = 0;
            // 
            // MainForm
            // 
            ClientSize = new Size(1184, 761);
            Controls.Add(tabMain);
            MinimumSize = new Size(900, 600);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SamBQ - 파일 다운로드 도구";
            tabMain.ResumeLayout(false);
            tabFtp.ResumeLayout(false);
            tabUrl.ResumeLayout(false);
            ResumeLayout(false);
        }

        protected override async void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            var connectForm = new Forms.FtpConnectForm();
            if (connectForm.ShowDialog() == DialogResult.OK && connectForm.SelectedProfile != null)
            {
                try
                {
                    this.Cursor = Cursors.WaitCursor;
                    await ftpPage.ConnectAsync(connectForm.SelectedProfile);
                    this.Text = $"SamBQ  ─  연결됨: {connectForm.SelectedProfile.Host}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        $"FTP 접속 실패:\n{ex.Message}",
                        "접속 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    this.Cursor = Cursors.Default;
                }
            }
        }
    }
}
