namespace SamBQ.Forms
{
    partial class FtpDownloadPage
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        private void InitializeComponent()
        {
            panelTop = new Panel();
            panelProgress = new Panel();
            progressBar = new ProgressBar();
            lblProgress = new Label();
            lblCsvFmt = new Label();
            flowSearch = new FlowLayoutPanel();
            chkLike = new CheckBox();
            txtSearchFile = new TextBox();
            btnSearch = new Button();
            btnCsvUpload = new Button();
            lblCsvCount = new Label();
            btnMultiStart = new Button();
            btnStop = new Button();
            lblInterval = new Label();
            numInterval = new NumericUpDown();
            lblGuide = new Label();
            lblCurrentPath = new TextBox();
            panelPath = new Panel();
            txtLocalPath = new TextBox();
            btnBrowse = new Button();
            btnOpenFolder = new Button();
            lblLocal = new Label();
            splitContainer = new SplitContainer();
            treeServer = new TreeView();
            panelRight = new Panel();
            listFiles = new ListView();
            colFileName = new ColumnHeader();
            colSize = new ColumnHeader();
            colModified = new ColumnHeader();
            btnDownloadSel = new Button();
            panelTop.SuspendLayout();
            panelProgress.SuspendLayout();
            flowSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numInterval).BeginInit();
            panelPath.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer).BeginInit();
            splitContainer.Panel1.SuspendLayout();
            splitContainer.Panel2.SuspendLayout();
            splitContainer.SuspendLayout();
            panelRight.SuspendLayout();
            SuspendLayout();
            // 
            // panelTop
            // 
            panelTop.Controls.Add(panelProgress);
            panelTop.Controls.Add(lblCsvFmt);
            panelTop.Controls.Add(flowSearch);
            panelTop.Controls.Add(lblGuide);
            panelTop.Controls.Add(lblCurrentPath);
            panelTop.Dock = DockStyle.Top;
            panelTop.Location = new Point(0, 0);
            panelTop.Name = "panelTop";
            panelTop.Padding = new Padding(6);
            panelTop.Size = new Size(1380, 155);
            panelTop.TabIndex = 0;
            // 
            // panelProgress
            // 
            panelProgress.Controls.Add(progressBar);
            panelProgress.Controls.Add(lblProgress);
            panelProgress.Dock = DockStyle.Top;
            panelProgress.Location = new Point(6, 103);
            panelProgress.Name = "panelProgress";
            panelProgress.Padding = new Padding(0, 4, 0, 4);
            panelProgress.Size = new Size(1368, 30);
            panelProgress.TabIndex = 4;
            // 
            // progressBar
            // 
            progressBar.Dock = DockStyle.Fill;
            progressBar.Location = new Point(0, 4);
            progressBar.Name = "progressBar";
            progressBar.Size = new Size(1288, 22);
            progressBar.TabIndex = 0;
            // 
            // lblProgress
            // 
            lblProgress.Dock = DockStyle.Right;
            lblProgress.Location = new Point(1288, 4);
            lblProgress.Name = "lblProgress";
            lblProgress.Padding = new Padding(6, 0, 0, 0);
            lblProgress.Size = new Size(80, 22);
            lblProgress.TabIndex = 1;
            lblProgress.Text = "0 / 0";
            lblProgress.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblCsvFmt
            // 
            lblCsvFmt.Dock = DockStyle.Top;
            lblCsvFmt.ForeColor = Color.DarkOrange;
            lblCsvFmt.Location = new Point(6, 80);
            lblCsvFmt.Name = "lblCsvFmt";
            lblCsvFmt.Padding = new Padding(0, 4, 0, 4);
            lblCsvFmt.Size = new Size(1368, 23);
            lblCsvFmt.TabIndex = 3;
            lblCsvFmt.Text = "CSV 형식: 경로, 파일명, LIKE검색여부(yes/no), 파일명변경여부(yes/no), 변경파일명";
            // 
            // flowSearch
            // 
            flowSearch.Controls.Add(chkLike);
            flowSearch.Controls.Add(txtSearchFile);
            flowSearch.Controls.Add(btnSearch);
            flowSearch.Controls.Add(btnCsvUpload);
            flowSearch.Controls.Add(lblCsvCount);
            flowSearch.Controls.Add(btnMultiStart);
            flowSearch.Controls.Add(btnStop);
            flowSearch.Controls.Add(lblInterval);
            flowSearch.Controls.Add(numInterval);
            flowSearch.Dock = DockStyle.Top;
            flowSearch.Location = new Point(6, 44);
            flowSearch.Name = "flowSearch";
            flowSearch.Size = new Size(1368, 36);
            flowSearch.TabIndex = 2;
            flowSearch.WrapContents = false;
            // 
            // chkLike
            // 
            chkLike.AutoSize = true;
            chkLike.Location = new Point(3, 7);
            chkLike.Margin = new Padding(3, 7, 3, 3);
            chkLike.Name = "chkLike";
            chkLike.Size = new Size(76, 19);
            chkLike.TabIndex = 0;
            chkLike.Text = "LIKE 검색";
            // 
            // txtSearchFile
            // 
            txtSearchFile.Location = new Point(85, 6);
            txtSearchFile.Margin = new Padding(3, 6, 3, 3);
            txtSearchFile.Name = "txtSearchFile";
            txtSearchFile.Size = new Size(295, 23);
            txtSearchFile.TabIndex = 1;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(386, 4);
            btnSearch.Margin = new Padding(3, 4, 3, 3);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(65, 28);
            btnSearch.TabIndex = 2;
            btnSearch.Text = "검색";
            btnSearch.Click += BtnSearch_Click;
            // 
            // btnCsvUpload
            // 
            btnCsvUpload.BackColor = Color.FromArgb(0, 122, 204);
            btnCsvUpload.ForeColor = Color.White;
            btnCsvUpload.Location = new Point(466, 4);
            btnCsvUpload.Margin = new Padding(12, 4, 3, 3);
            btnCsvUpload.Name = "btnCsvUpload";
            btnCsvUpload.Size = new Size(90, 28);
            btnCsvUpload.TabIndex = 3;
            btnCsvUpload.Text = "CSV 업로드";
            btnCsvUpload.UseVisualStyleBackColor = false;
            btnCsvUpload.Click += BtnCsvUpload_Click;
            // 
            // lblCsvCount
            // 
            lblCsvCount.AutoSize = true;
            lblCsvCount.Location = new Point(562, 10);
            lblCsvCount.Margin = new Padding(3, 10, 3, 3);
            lblCsvCount.Name = "lblCsvCount";
            lblCsvCount.Size = new Size(62, 15);
            lblCsvCount.TabIndex = 4;
            lblCsvCount.Text = "  총  0개  ";
            // 
            // btnMultiStart
            // 
            btnMultiStart.BackColor = Color.ForestGreen;
            btnMultiStart.ForeColor = Color.White;
            btnMultiStart.Location = new Point(639, 4);
            btnMultiStart.Margin = new Padding(12, 4, 3, 3);
            btnMultiStart.Name = "btnMultiStart";
            btnMultiStart.Size = new Size(110, 28);
            btnMultiStart.TabIndex = 5;
            btnMultiStart.Text = "다중 처리 시작";
            btnMultiStart.UseVisualStyleBackColor = false;
            btnMultiStart.Click += BtnMultiStart_Click;
            // 
            // btnStop
            // 
            btnStop.BackColor = Color.Tomato;
            btnStop.ForeColor = Color.White;
            btnStop.Location = new Point(755, 4);
            btnStop.Margin = new Padding(3, 4, 3, 3);
            btnStop.Name = "btnStop";
            btnStop.Size = new Size(65, 28);
            btnStop.TabIndex = 6;
            btnStop.Text = "■ 중지";
            btnStop.UseVisualStyleBackColor = false;
            btnStop.Click += BtnStop_Click;
            // 
            // lblInterval
            // 
            lblInterval.AutoSize = true;
            lblInterval.Location = new Point(835, 10);
            lblInterval.Margin = new Padding(12, 10, 3, 3);
            lblInterval.Name = "lblInterval";
            lblInterval.Size = new Size(54, 15);
            lblInterval.TabIndex = 7;
            lblInterval.Text = "간격(초):";
            // 
            // numInterval
            // 
            numInterval.DecimalPlaces = 1;
            numInterval.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
            numInterval.Location = new Point(895, 6);
            numInterval.Margin = new Padding(3, 6, 3, 3);
            numInterval.Maximum = new decimal(new int[] { 60, 0, 0, 0 });
            numInterval.Minimum = new decimal(new int[] { 1, 0, 0, 65536 });
            numInterval.Name = "numInterval";
            numInterval.Size = new Size(70, 23);
            numInterval.TabIndex = 8;
            numInterval.Value = new decimal(new int[] { 5, 0, 0, 65536 });
            // 
            // lblGuide
            // 
            lblGuide.Dock = DockStyle.Top;
            lblGuide.ForeColor = Color.DimGray;
            lblGuide.Location = new Point(6, 22);
            lblGuide.Name = "lblGuide";
            lblGuide.Padding = new Padding(0, 2, 0, 2);
            lblGuide.Size = new Size(1368, 22);
            lblGuide.TabIndex = 1;
            lblGuide.Text = "현재 폴더를 포함한 하위 폴더 전체에서 검색합니다.";
            // 
            // lblCurrentPath
            // 
            lblCurrentPath.BackColor = SystemColors.Control;
            lblCurrentPath.BorderStyle = BorderStyle.None;
            lblCurrentPath.Dock = DockStyle.Top;
            lblCurrentPath.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            lblCurrentPath.Location = new Point(6, 6);
            lblCurrentPath.Name = "lblCurrentPath";
            lblCurrentPath.ReadOnly = true;
            lblCurrentPath.Size = new Size(1368, 16);
            lblCurrentPath.TabIndex = 0;
            lblCurrentPath.Text = "현재 경로: (미접속)";
            // 
            // panelPath
            // 
            panelPath.Controls.Add(txtLocalPath);
            panelPath.Controls.Add(btnBrowse);
            panelPath.Controls.Add(btnOpenFolder);
            panelPath.Controls.Add(lblLocal);
            panelPath.Dock = DockStyle.Top;
            panelPath.Location = new Point(0, 155);
            panelPath.Name = "panelPath";
            panelPath.Padding = new Padding(6, 4, 6, 4);
            panelPath.Size = new Size(1380, 34);
            panelPath.TabIndex = 1;
            // 
            // txtLocalPath
            // 
            txtLocalPath.Dock = DockStyle.Fill;
            txtLocalPath.Location = new Point(72, 4);
            txtLocalPath.Name = "txtLocalPath";
            txtLocalPath.Size = new Size(1077, 23);
            txtLocalPath.TabIndex = 1;
            // 
            // btnBrowse
            // 
            btnBrowse.Dock = DockStyle.Right;
            btnBrowse.Location = new Point(1149, 4);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(140, 26);
            btnBrowse.TabIndex = 2;
            btnBrowse.Text = "폴더 선택";
            btnBrowse.Click += BtnBrowse_Click;
            // 
            // btnOpenFolder
            // 
            btnOpenFolder.Dock = DockStyle.Right;
            btnOpenFolder.Location = new Point(1289, 4);
            btnOpenFolder.Name = "btnOpenFolder";
            btnOpenFolder.Size = new Size(85, 26);
            btnOpenFolder.TabIndex = 3;
            btnOpenFolder.Text = "탐색기 열기";
            btnOpenFolder.Click += BtnOpenFolder_Click;
            // 
            // lblLocal
            // 
            lblLocal.Dock = DockStyle.Left;
            lblLocal.Location = new Point(6, 4);
            lblLocal.Name = "lblLocal";
            lblLocal.Padding = new Padding(0, 3, 6, 0);
            lblLocal.Size = new Size(66, 26);
            lblLocal.TabIndex = 0;
            lblLocal.Text = "저장 경로:";
            // 
            // splitContainer
            // 
            splitContainer.Dock = DockStyle.Fill;
            splitContainer.Location = new Point(0, 189);
            splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            splitContainer.Panel1.Controls.Add(treeServer);
            // 
            // splitContainer.Panel2
            // 
            splitContainer.Panel2.Controls.Add(panelRight);
            splitContainer.Size = new Size(1380, 549);
            splitContainer.SplitterDistance = 386;
            splitContainer.TabIndex = 2;
            // 
            // treeServer
            // 
            treeServer.Dock = DockStyle.Fill;
            treeServer.Location = new Point(0, 0);
            treeServer.Name = "treeServer";
            treeServer.Size = new Size(386, 549);
            treeServer.TabIndex = 0;
            treeServer.BeforeExpand += TreeServer_BeforeExpand;
            treeServer.AfterSelect += TreeServer_AfterSelect;
            // 
            // panelRight
            // 
            panelRight.Controls.Add(listFiles);
            panelRight.Controls.Add(btnDownloadSel);
            panelRight.Dock = DockStyle.Fill;
            panelRight.Location = new Point(0, 0);
            panelRight.Name = "panelRight";
            panelRight.Size = new Size(990, 549);
            panelRight.TabIndex = 0;
            // 
            // listFiles
            // 
            listFiles.CheckBoxes = true;
            listFiles.Columns.AddRange(new ColumnHeader[] { colFileName, colSize, colModified });
            listFiles.Dock = DockStyle.Fill;
            listFiles.FullRowSelect = true;
            listFiles.Location = new Point(0, 0);
            listFiles.Name = "listFiles";
            listFiles.Size = new Size(990, 517);
            listFiles.TabIndex = 0;
            listFiles.UseCompatibleStateImageBehavior = false;
            listFiles.View = View.Details;
            // 
            // colFileName
            // 
            colFileName.Text = "파일명";
            colFileName.Width = 300;
            // 
            // colSize
            // 
            colSize.Text = "크기";
            colSize.Width = 100;
            // 
            // colModified
            // 
            colModified.Text = "수정일";
            colModified.Width = 160;
            // 
            // btnDownloadSel
            // 
            btnDownloadSel.BackColor = Color.SteelBlue;
            btnDownloadSel.Dock = DockStyle.Bottom;
            btnDownloadSel.ForeColor = Color.White;
            btnDownloadSel.Location = new Point(0, 517);
            btnDownloadSel.Name = "btnDownloadSel";
            btnDownloadSel.Size = new Size(990, 32);
            btnDownloadSel.TabIndex = 1;
            btnDownloadSel.Text = "선택 파일 다운로드";
            btnDownloadSel.UseVisualStyleBackColor = false;
            btnDownloadSel.Click += BtnDownloadSelected_Click;
            // 
            // FtpDownloadPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(splitContainer);
            Controls.Add(panelPath);
            Controls.Add(panelTop);
            Name = "FtpDownloadPage";
            Size = new Size(1380, 738);
            panelTop.ResumeLayout(false);
            panelTop.PerformLayout();
            panelProgress.ResumeLayout(false);
            flowSearch.ResumeLayout(false);
            flowSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numInterval).EndInit();
            panelPath.ResumeLayout(false);
            panelPath.PerformLayout();
            splitContainer.Panel1.ResumeLayout(false);
            splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer).EndInit();
            splitContainer.ResumeLayout(false);
            panelRight.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panelTop;
        private TextBox lblCurrentPath;
        private Label lblGuide;
        private FlowLayoutPanel flowSearch;
        private CheckBox chkLike;
        private TextBox txtSearchFile;
        private Button btnSearch;
        private Button btnCsvUpload;
        private Label lblCsvCount;
        private Button btnMultiStart;
        private Button btnStop;
        private Label lblInterval;
        private NumericUpDown numInterval;
        private Label lblCsvFmt;
        private Panel panelProgress;
        private ProgressBar progressBar;
        private Label lblProgress;
        private Panel panelPath;
        private Label lblLocal;
        private TextBox txtLocalPath;
        private Button btnBrowse;
        private Button btnOpenFolder;
        private SplitContainer splitContainer;
        private TreeView treeServer;
        private Panel panelRight;
        private ListView listFiles;
        private ColumnHeader colFileName;
        private ColumnHeader colSize;
        private ColumnHeader colModified;
        private Button btnDownloadSel;
    }
}
