using SamBQ.Models;

namespace SamBQ.Forms
{
    public class FtpConnectForm : Form
    {
        private TextBox txtName = null!;
        private TextBox txtHost = null!;
        private NumericUpDown numPort = null!;
        private TextBox txtUser = null!;
        private TextBox txtPassword = null!;
        private ListBox lstProfiles = null!;
        private Button btnSave = null!;
        private Button btnDelete = null!;
        private Button btnConnect = null!;
        private Button btnCancel = null!;

        public ConnectionProfile? SelectedProfile { get; private set; }
        private List<ConnectionProfile> _profiles = new();

        public FtpConnectForm()
        {
            InitializeComponent();
            LoadProfiles();
        }

        private void InitializeComponent()
        {
            this.Text = "FTP 서버 접속";
            this.Size = new Size(500, 450);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            var lblTitle = new Label
            {
                Text = "접속 정보 입력",
                Font = new Font("맑은 고딕", 11, FontStyle.Bold),
                Location = new Point(15, 15),
                AutoSize = true
            };

            var lblName = new Label { Text = "접속명:", Location = new Point(15, 50), AutoSize = true };
            txtName = new TextBox { Location = new Point(80, 47), Width = 280 };

            var lblHost = new Label { Text = "호스트:", Location = new Point(15, 85), AutoSize = true };
            txtHost = new TextBox { Location = new Point(80, 82), Width = 220 };

            var lblPort = new Label { Text = "포트:", Location = new Point(310, 85), AutoSize = true };
            numPort = new NumericUpDown
            {
                Location = new Point(345, 82), Width = 75,
                Minimum = 1, Maximum = 65535, Value = 21
            };

            var lblUser = new Label { Text = "아이디:", Location = new Point(15, 120), AutoSize = true };
            txtUser = new TextBox { Location = new Point(80, 117), Width = 160 };

            var lblPw = new Label { Text = "암호:", Location = new Point(250, 120), AutoSize = true };
            txtPassword = new TextBox { Location = new Point(290, 117), Width = 130, PasswordChar = '*' };

            btnSave = new Button { Text = "저장", Location = new Point(15, 155), Width = 75 };
            btnSave.Click += BtnSave_Click;

            btnDelete = new Button { Text = "삭제", Location = new Point(100, 155), Width = 75 };
            btnDelete.Click += BtnDelete_Click;

            var lblList = new Label { Text = "저장된 접속명 목록:", Location = new Point(15, 195), AutoSize = true };
            lstProfiles = new ListBox { Location = new Point(15, 215), Width = 450, Height = 140 };
            lstProfiles.SelectedIndexChanged += LstProfiles_SelectedIndexChanged;
            lstProfiles.DoubleClick += (s, e) => BtnConnect_Click(s, e);

            btnConnect = new Button { Text = "접속", Location = new Point(280, 375), Width = 90, Height = 32 };
            btnConnect.BackColor = Color.SteelBlue;
            btnConnect.ForeColor = Color.White;
            btnConnect.Click += BtnConnect_Click;

            btnCancel = new Button { Text = "취소", Location = new Point(380, 375), Width = 85, Height = 32 };
            btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; this.Close(); };

            this.Controls.AddRange(new Control[] {
                lblTitle, lblName, txtName, lblHost, txtHost, lblPort, numPort,
                lblUser, txtUser, lblPw, txtPassword,
                btnSave, btnDelete, lblList, lstProfiles, btnConnect, btnCancel
            });
        }

        private void LoadProfiles()
        {
            _profiles = ConnectionProfile.LoadAll();
            RefreshList();
        }

        private void RefreshList()
        {
            lstProfiles.Items.Clear();
            foreach (var p in _profiles)
                lstProfiles.Items.Add(p.Name);
        }

        private void LstProfiles_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (lstProfiles.SelectedIndex < 0) return;
            var p = _profiles[lstProfiles.SelectedIndex];
            txtName.Text = p.Name;
            txtHost.Text = p.Host;
            numPort.Value = p.Port;
            txtUser.Text = p.UserId;
            txtPassword.Text = p.Password;
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("접속명을 입력하세요.", "알림");
                return;
            }

            var existing = _profiles.FirstOrDefault(p => p.Name == txtName.Text);
            if (existing != null)
            {
                existing.Host = txtHost.Text;
                existing.Port = (int)numPort.Value;
                existing.UserId = txtUser.Text;
                existing.Password = txtPassword.Text;
            }
            else
            {
                _profiles.Add(new ConnectionProfile
                {
                    Name = txtName.Text,
                    Host = txtHost.Text,
                    Port = (int)numPort.Value,
                    UserId = txtUser.Text,
                    Password = txtPassword.Text
                });
            }
            ConnectionProfile.SaveAll(_profiles);
            RefreshList();
            MessageBox.Show("저장되었습니다.", "알림");
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (lstProfiles.SelectedIndex < 0)
            {
                MessageBox.Show("삭제할 항목을 선택하세요.");
                return;
            }
            _profiles.RemoveAt(lstProfiles.SelectedIndex);
            ConnectionProfile.SaveAll(_profiles);
            RefreshList();
        }

        private void BtnConnect_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHost.Text))
            {
                MessageBox.Show("호스트를 입력하세요.", "알림");
                return;
            }

            SelectedProfile = new ConnectionProfile
            {
                Name = txtName.Text,
                Host = txtHost.Text,
                Port = (int)numPort.Value,
                UserId = txtUser.Text,
                Password = txtPassword.Text
            };
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
