# SamBQ - 파일 다운로드 도구

## 프로젝트 구조

```
SamBQ/
├── SamBQ.csproj
├── Program.cs
├── MainForm.cs                     ← 메인 창 (TabControl)
├── Models/
│   └── Models.cs                   ← FtpProfile, CsvDownloadItem, UrlDownloadItem
├── Forms/
│   ├── FtpConnectForm.cs           ← FTP 접속 정보 팝업
│   ├── FtpDownloadPage.cs          ← 탭1: 파일서버 다운로드
│   └── UrlDownloadPage.cs          ← 탭2: URL 다운로드
├── sample_ftp_download.csv         ← FTP 다운로드 CSV 예시
└── sample_url_download.csv         ← URL 다운로드 CSV 예시
```

## 빌드 및 실행

### 요구사항
- .NET 6.0 SDK (Windows)
- Visual Studio 2022 또는 .NET CLI

### CLI 빌드
```bash
cd H:\05.prj\Clode\SamBQ\SamBQ
dotnet restore
dotnet build
dotnet run
```

### Visual Studio
1. `SamBQ.csproj` 더블클릭으로 프로젝트 열기
2. F5 실행

---

## 기능 설명

### 탭1: 파일서버 다운로드 (FTP)

| 영역 | 설명 |
|------|------|
| **접속 팝업** | 프로그램 시작 시 자동 표시. 접속명으로 저장/불러오기 가능 |
| **상단 경로** | 현재 선택된 FTP 경로 표시 |
| **검색** | LIKE/완전일치 검색, 현재 폴더 포함 하위 전체 재귀 탐색 |
| **CSV 업로드** | 배치 다운로드 목록 지정 |
| **다중 처리** | CSV 순서대로 자동 다운로드, 파일명 변경 지원 |
| **다운 간격** | 최소 0.1초, 기본 0.5초 |
| **30GB 제한** | 초과 시 마지막 파일 완료 후 경고 팝업 |
| **트리뷰** | FTP 디렉토리 계층 탐색 |
| **파일 목록** | 체크박스로 선택 다운로드 |
| **저장 경로** | 로컬 폴더 선택 |

#### FTP CSV 형식
```
경로,파일명,LIKE검색여부,파일명변경여부,변경파일명
/data/reports,2024_report.pdf,no,no,
/data/images,banner,yes,yes,main_banner.jpg
```

---

### 탭2: URL 다운로드

| 영역 | 설명 |
|------|------|
| **다운 간격** | 최소 0.1초 제한 |
| **CSV 업로드** | URL 목록 일괄 지정 |
| **업로드 행수** | 로드된 항목 수 표시 |
| **다운로드 시작/중지** | 순차 다운로드, 중간 중지 가능 |
| **저장 경로** | 로컬 폴더 선택 |
| **진행률** | 프로그레스바 + 개수 표시 |
| **이미지 URL** | 이미지 링크도 바이트 다운로드로 저장 |

#### URL CSV 형식
```
대상URL,변경파일명,index
https://example.com/banner.jpg,main_banner.jpg,001
https://example.com/doc.pdf,report.pdf,002
```

---

## 설정 파일
- `ftp_profiles.json` : FTP 접속 정보 (자동 생성, 실행 파일 위치)

## 의존성
- **FluentFTP** v49 (NuGet) - FTP 클라이언트
- **System.Net.Http** (내장) - URL 다운로드
