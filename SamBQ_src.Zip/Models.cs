using System.Text.Json;

namespace SamBQ.Models
{
    public class ConnectionProfile
    {
        public string Name { get; set; } = "";
        public string Host { get; set; } = "";
        public int Port { get; set; } = 21;
        public string UserId { get; set; } = "";
        public string Password { get; set; } = "";

        private static readonly string ProfilePath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ftp_profiles.json");

        public static List<ConnectionProfile> LoadAll()
        {
            if (!File.Exists(ProfilePath)) return new List<ConnectionProfile>();
            try
            {
                var json = File.ReadAllText(ProfilePath);
                return JsonSerializer.Deserialize<List<ConnectionProfile>>(json) ?? new List<ConnectionProfile>();
            }
            catch { return new List<ConnectionProfile>(); }
        }

        public static void SaveAll(List<ConnectionProfile> profiles)
        {
            var json = JsonSerializer.Serialize(profiles, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(ProfilePath, json);
        }
    }

    public class CsvDownloadItem
    {
        public string RemotePath { get; set; } = "";
        public string FileName { get; set; } = "";
        public bool LikeSearch { get; set; } = false;
        public bool RenameFile { get; set; } = false;
        public string NewFileName { get; set; } = "";
        public string Status { get; set; } = "대기";
    }

    public class UrlDownloadItem
    {
        public string Url { get; set; } = "";
        public string NewFileName { get; set; } = "";
        public string Index { get; set; } = "";
        public string Status { get; set; } = "대기";
    }
}
